<?php

namespace Tigren\Engine\Model\Data;

use Magento\Framework\DataObject;
use Tigren\Engine\Api\Data\EngineInterface;

class Engine extends DataObject implements EngineInterface
{
    /**
     * Getter for EngineId.
     *
     * @return string|null
     */
    public function getEngineId(): ?string
    {
        return $this->getData(self::ENGINE_ID);
    }

    /**
     * Setter for EngineId.
     *
     * @param string|null $engineId
     *
     * @return void
     */
    public function setEngineId(?string $engineId): void
    {
        $this->setData(self::ENGINE_ID, $engineId);
    }

    /**
     * Getter for Name.
     *
     * @return string|null
     */
    public function getName(): ?string
    {
        return $this->getData(self::NAME);
    }

    /**
     * Setter for Name.
     *
     * @param string|null $name
     *
     * @return void
     */
    public function setName(?string $name): void
    {
        $this->setData(self::NAME, $name);
    }

    /**
     * Getter for Status.
     *
     * @return string|null
     */
    public function getStatus(): ?string
    {
        return $this->getData(self::STATUS);
    }

    /**
     * Setter for Status.
     *
     * @param string|null $status
     *
     * @return void
     */
    public function setStatus(?string $status): void
    {
        $this->setData(self::STATUS, $status);
    }

    /**
     * Getter for TransactionsMechanism.
     *
     * @return string|null
     */
    public function getTransactionsMechanism(): ?string
    {
        return $this->getData(self::TRANSACTIONS_MECHANISM);
    }

    /**
     * Setter for TransactionsMechanism.
     *
     * @param string|null $transactionsMechanism
     *
     * @return void
     */
    public function setTransactionsMechanism(?string $transactionsMechanism): void
    {
        $this->setData(self::TRANSACTIONS_MECHANISM, $transactionsMechanism);
    }

    /**
     * Getter for SupportedTransactionTypes.
     *
     * @return string|null
     */
    public function getSupportedTransactionTypes(): ?string
    {
        return $this->getData(self::SUPPORTED_TRANSACTION_TYPES);
    }

    /**
     * Setter for SupportedTransactionTypes.
     *
     * @param string|null $supportedTransactionTypes
     *
     * @return void
     */
    public function setSupportedTransactionTypes(?string $supportedTransactionTypes): void
    {
        $this->setData(self::SUPPORTED_TRANSACTION_TYPES, $supportedTransactionTypes);
    }

    /**
     * Getter for Programs.
     *
     * @return \Tigren\Engine\Api\Data\ProgramInterface[]
     */
    public function getPrograms()
    {
        return $this->getData(self::PROGRAMS);
    }

    /**
     * Setter for Programs.
     *
     * @param string|null $programs
     *
     * @return void
     */

    /**
     * @param \Tigren\Engine\Api\Data\ProgramInterface[] $programs
     * @return $this|Engine
     */
    public function setPrograms(?array $programs)
    {
        $this->setData(self::PROGRAMS, $programs);

        return $this;
    }
}
