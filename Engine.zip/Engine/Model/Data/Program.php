<?php

namespace Tigren\Engine\Model\Data;

use Magento\Framework\DataObject;
use Tigren\Engine\Api\Data\ProgramInterface;

class Program extends DataObject implements ProgramInterface
{
    /**
     * Getter for ProgramId.
     *
     * @return string|null
     */
    public function getProgramId(): ?string
    {
        return $this->getData(self::PROGRAM_ID);
    }

    /**
     * Setter for ProgramId.
     *
     * @param string|null $programId
     *
     * @return void
     */
    public function setProgramId(?string $programId): void
    {
        $this->setData(self::PROGRAM_ID, $programId);
    }

    /**
     * Getter for Name.
     *
     * @return string|null
     */
    public function getName(): ?string
    {
        return $this->getData(self::NAME);
    }

    /**
     * Setter for Name.
     *
     * @param string|null $name
     *
     * @return void
     */
    public function setName(?string $name): void
    {
        $this->setData(self::NAME, $name);
    }
}
