<?php

namespace Tigren\Engine\Model;

class EngineManagement
{
    public function getEngineSummary(string $engineId)
    {

    }
}
