<?php

namespace Tigren\Engine\Api\Data;

interface EngineInterface
{
    /**
     * String constants for property names
     */
    public const ENGINE_ID = "engine_id";
    public const NAME = "name";
    public const STATUS = "status";
    public const TRANSACTIONS_MECHANISM = "transactions_mechanism";
    public const SUPPORTED_TRANSACTION_TYPES = "supported_transaction_types";
    public const PROGRAMS = "programs";

    /**
     * Getter for EngineId.
     *
     * @return string|null
     */
    public function getEngineId(): ?string;

    /**
     * Setter for EngineId.
     *
     * @param string|null $engineId
     *
     * @return void
     */
    public function setEngineId(?string $engineId): void;

    /**
     * Getter for Name.
     *
     * @return string|null
     */
    public function getName(): ?string;

    /**
     * Setter for Name.
     *
     * @param string|null $name
     *
     * @return void
     */
    public function setName(?string $name): void;

    /**
     * Getter for Status.
     *
     * @return string|null
     */
    public function getStatus(): ?string;

    /**
     * Setter for Status.
     *
     * @param string|null $status
     *
     * @return void
     */
    public function setStatus(?string $status): void;

    /**
     * Getter for TransactionsMechanism.
     *
     * @return string|null
     */
    public function getTransactionsMechanism(): ?string;

    /**
     * Setter for TransactionsMechanism.
     *
     * @param string|null $transactionsMechanism
     *
     * @return void
     */
    public function setTransactionsMechanism(?string $transactionsMechanism): void;

    /**
     * Getter for SupportedTransactionTypes.
     *
     * @return string|null
     */
    public function getSupportedTransactionTypes(): ?string;

    /**
     * Setter for SupportedTransactionTypes.
     *
     * @param string|null $supportedTransactionTypes
     *
     * @return void
     */
    public function setSupportedTransactionTypes(?string $supportedTransactionTypes): void;

    /**
     * Getter for Programs.
     *
     * @return \Tigren\Engine\Api\Data\ProgramInterface[]
     */
    public function getPrograms();

    /**
     * Setter for Programs.
     *
     * @param \Tigren\Engine\Api\Data\ProgramInterface[] $programs
     * @return $this
     */
    public function setPrograms(?array $programs);
}
