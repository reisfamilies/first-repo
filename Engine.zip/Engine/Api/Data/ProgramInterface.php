<?php

namespace Tigren\Engine\Api\Data;

interface ProgramInterface
{
    /**
     * String constants for property names
     */
    public const PROGRAM_ID = "program_id";
    public const NAME = "name";

    /**
     * Getter for ProgramId.
     *
     * @return string|null
     */
    public function getProgramId(): ?string;

    /**
     * Setter for ProgramId.
     *
     * @param string|null $programId
     *
     * @return void
     */
    public function setProgramId(?string $programId): void;

    /**
     * Getter for Name.
     *
     * @return string|null
     */
    public function getName(): ?string;

    /**
     * Setter for Name.
     *
     * @param string|null $name
     *
     * @return void
     */
    public function setName(?string $name): void;
}
