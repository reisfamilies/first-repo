<?php

namespace Tigren\Engine\Api;

interface EngineManagementInterface
{
    public function getEngineSummary(string $engineId);
}
