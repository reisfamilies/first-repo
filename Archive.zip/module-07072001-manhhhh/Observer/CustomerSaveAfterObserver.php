<?php


namespace Manh\Chu\Observer;

use Magento\Framework\Event\ObserverInterface;
use Manh\Chu\Model\DealerCustomerFactory;

class CustomerSaveAfterObserver implements ObserverInterface
{
    /** @var \Manh\Chu\Helper\Data  */
    protected $_permHelper;

    /** @var \Magento\Framework\App\Request\Http  */
    protected $_request;

    /** @var \Manh\Chu\Model\DealerFactory  */
    protected $_dealerFactory;

    /**
     * @var DealerCustomerFactory
     */
    protected $dealerCustomerFactory;

    /**
     * @param \Manh\Chu\Helper\Data $permHelper
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Manh\Chu\Model\DealerFactory $dealerFactory
     */
    public function __construct(
        \Manh\Chu\Helper\Data $permHelper,
        \Magento\Framework\App\Request\Http $request,
        \Manh\Chu\Model\DealerFactory $dealerFactory,
        DealerCustomerFactory $dealerCustomerFactory
    ){
        $this->_permHelper = $permHelper;
        $this->_request = $request;
        $this->_dealerFactory = $dealerFactory;
        $this->dealerCustomerFactory = $dealerCustomerFactory;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $dealerId = null;

        $manhPermData = $this->_request->getParam('manh_perm'); //customer registration form frontend
        $customerData = $this->_request->getParam('customer'); //customer edit on backend

        if ($manhPermData && array_key_exists('dealer_id', $manhPermData)){
            $dealerId = $manhPermData['dealer_id'];
        } else if ($customerData && array_key_exists('manh_perm_dealer', $customerData)){
            $dealerId = $customerData['manh_perm_dealer'];
        } else if ($this->_permHelper->isBackendDealer()){
            $dealerId = $this->_permHelper->getBackendDealer()->getId();
        }

        if ($dealerId !== null){

            $customer = $observer->getEvent()->getData('data_object');

            if (!$customer) {
                $customer = $observer->getEvent()->getData('customer_data_object');
            }

            $dealer = $this->_dealerFactory->create()->load($dealerId);
            if ($dealer->getId()) {
                $dealer->saveCustomers([$customer->getId()], false);
            } else {
                $dealerCustomer = $this->dealerCustomerFactory->create()->load($customer->getId(), 'customer_id');
                if ($dealerCustomer->getId()){
                    $dealerCustomer->delete();
                }
            }
        }
    }
}
