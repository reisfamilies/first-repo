<?php

namespace Manh\Chu\Observer;

use Magento\Framework\Event\ObserverInterface;
use \Manh\Chu\Helper\Data as Helper;

class SalesOrderLoadAfterObserver implements ObserverInterface
{
    /**
     * @var Helper
     */
    private $_permHelper;

    public function __construct(
        Helper $permHelper
    ) {
        $this->_permHelper = $permHelper;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getEvent()->getData('data_object');
        $this->_permHelper->checkPermissionsByOrder($order);
    }
}
