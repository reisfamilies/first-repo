<?php


namespace Manh\Chu\Observer;

use Manh\Chu\Helper\Data;
use Magento\Framework\Event\ObserverInterface;

class CustomerLoadAfterObserver implements ObserverInterface
{
    /**
     * @var Data
     */
    private $_permHelper;

    public function __construct(
        Data $permHelper
    ) {
        $this->_permHelper = $permHelper;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $customer = $observer->getEvent()->getData('data_object');
        $this->_permHelper->checkPermissionsByCustomerId($customer->getId());
    }
}
