<?php

namespace Manh\Chu\Model\ResourceModel\Role;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init('Manh\Chu\Model\Role', 'Manh\Chu\Model\ResourceModel\Role');
        $this->_setIdFieldName($this->getResource()->getIdFieldName());
    }
}