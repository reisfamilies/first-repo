<?php





namespace Manh\Chu\Model\ResourceModel;

use Manh\Chu\Helper\Data;

class DealerCustomer extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        Data $helper = null, // @deprecated. Backward compatibility
        $connectionName = null
    ) {
        return parent::__construct($context, $connectionName);
    }
    protected function _construct()
    {
        $this->_init('manh_perm_dealer_customer', 'entity_id');
    }

    public function getCustomers(\Manh\Chu\Model\Dealer $dealer)
    {
        $connection = $this->getConnection();

        $binds = ['dealer_id' => $dealer->getId()];

        $select = $connection->select()
            ->from($this->getMainTable(), ['customer_id'])
            ->where('dealer_id = :dealer_id');

        return $connection->fetchCol($select, $binds);
    }
}
