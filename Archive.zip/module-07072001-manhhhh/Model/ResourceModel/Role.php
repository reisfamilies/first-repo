<?php

namespace Manh\Chu\Model\ResourceModel;

class Role extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('manh_perm_role', 'entity_id');
    }
}