<?php

namespace Manh\Chu\Model\ResourceModel;

class DealerOrder extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('manh_perm_dealer_order', 'entity_id');
    }
}
