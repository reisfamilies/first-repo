<?php

namespace Manh\Chu\Model;

class Role extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Manh\Chu\Model\ResourceModel\Role');
    }
}