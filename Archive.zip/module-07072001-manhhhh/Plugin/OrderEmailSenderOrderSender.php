<?php

namespace Manh\Chu\Plugin;

use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Manh\Chu\Helper\Data as PermHelper;

class OrderEmailSenderOrderSender{

    protected $_permHelper;

    public function __construct(
        PermHelper $permHelper
    ){
        $this->_permHelper = $permHelper;
    }

    public function beforeSend(
        OrderSender $orderSender,
        Order $order,
        $forceSyncMode = false
    ){
        $this->_permHelper->loadDealers($order);
    }
}