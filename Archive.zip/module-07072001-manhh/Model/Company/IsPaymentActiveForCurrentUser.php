<?php





namespace Manh\Chu\Model\Company;

use Manh\Chu\Model\CompanyContext;
use Manh\Chu\Plugin\Checkout\Controller\Index\IndexPlugin;

class IsPaymentActiveForCurrentUser
{
    /**
     * @var CompanyContext
     */
    private $companyContext;

    public function __construct(CompanyContext $companyContext)
    {
        $this->companyContext = $companyContext;
    }

    /**
     * Check is payment method active for current user.
     *
     * @param string $methodCode
     * @return bool
     */
    public function execute(string $methodCode): bool
    {
        $company = $this->companyContext->getCurrentCompany();
        if (!$company->getCompanyId()) {
            return true;
        }

        return $company->getCompanyId()
            && $company->isActive()
            && $this->companyContext->isResourceAllow(IndexPlugin::RESOURCE)
            && !in_array($methodCode, $company->getRestrictedPayments(true), true);
    }
}
