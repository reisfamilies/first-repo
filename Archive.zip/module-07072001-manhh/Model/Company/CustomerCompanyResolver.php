<?php





namespace Manh\Chu\Model\Company;

use Manh\Chu\Api\Data\CustomerInterface as CompanyCustomerInterface;
use Magento\Customer\Model\ResourceModel\CustomerRepository;
use Magento\Framework\Exception\NoSuchEntityException;

class CustomerCompanyResolver
{
    /**
     * @var CustomerRepository
     */
    private $customerRepository;

    public function __construct(CustomerRepository $customerRepository)
    {
        $this->customerRepository = $customerRepository;
    }

    public function resolveForCustomerId(int $customerId): ?CompanyCustomerInterface
    {
        try {
            $customer = $this->customerRepository->getById($customerId);
        } catch (NoSuchEntityException $e) {
            return null;
        }

        $extension = $customer->getExtensionAttributes();

        if (!$extension) {
            return null;
        }

        /** @var CompanyCustomerInterface|null $amcompanyAttributes */
        $amcompanyAttributes = $extension->getAmcompanyAttributes();

        if (!$amcompanyAttributes || !$amcompanyAttributes->getCompanyId()) {
            return null;
        }

        return $amcompanyAttributes;
    }
}
