<?php





namespace Manh\Chu\Model\Company\Role\Acl;

use Magento\Framework\Acl\AclResource\Provider;

/**
 * ACL resource provider for company user roles.
 *
 * It should not be replaced with a virtual type
 * because we need to pluginize this class in Manh_CompanyAccountSubaccount.
 */
class ResourceProvider extends Provider
{
    /**
     * Cache key for ACL roles cache
     */
    public const ACL_RESOURCES_CACHE_KEY = 'amcompany_acl_cache';
}
