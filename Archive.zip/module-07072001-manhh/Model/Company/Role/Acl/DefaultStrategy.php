<?php





namespace Manh\Chu\Model\Company\Role\Acl;

class DefaultStrategy implements IsAclShowedStrategyInterface
{
    public function execute(): bool
    {
        return true;
    }
}
