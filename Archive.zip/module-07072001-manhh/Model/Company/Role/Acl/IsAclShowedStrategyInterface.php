<?php





namespace Manh\Chu\Model\Company\Role\Acl;

interface IsAclShowedStrategyInterface
{
    public function execute(): bool;
}
