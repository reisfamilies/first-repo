<?php





namespace Manh\Chu\Model\Company;

use Manh\Chu\Api\Data\CompanyInterface;
use Manh\Chu\Model\CustomerResolver;

class CurrentCompanyResolver
{
    /**
     * @var CustomerResolver
     */
    private $customerResolver;

    /**
     * @var CompanyResolver
     */
    private $companyResolver;

    /**
     * @var CustomerCompanyResolver
     */
    private $customerCompanyResolver;

    public function __construct(
        CustomerResolver $customerResolver,
        CompanyResolver $companyResolver,
        CustomerCompanyResolver $customerCompanyResolver
    ) {
        $this->customerResolver = $customerResolver;
        $this->companyResolver = $companyResolver;
        $this->customerCompanyResolver = $customerCompanyResolver;
    }

    public function getCurrentCompany(): ?CompanyInterface
    {
        $customerId = $this->customerResolver->getCustomerId();
        if ($customerId === null) {
            return null;
        }

        return $this->companyResolver->resolveCompanyByCustomerId($customerId);
    }

    public function getCurrentCompanyId(): ?int
    {
        $customerId = $this->customerResolver->getCustomerId();
        if ($customerId === null) {
            return null;
        }
        $companyAttributes = $this->customerCompanyResolver->resolveForCustomerId($customerId);
        if ($companyAttributes === null || !$companyAttributes->getCompanyId()) {
            return null;
        }

        return (int)$companyAttributes->getCompanyId();
    }
}
