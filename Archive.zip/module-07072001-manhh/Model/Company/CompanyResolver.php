<?php





namespace Manh\Chu\Model\Company;

use Manh\Chu\Api\CompanyRepositoryInterface;
use Manh\Chu\Api\Data\CompanyInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class CompanyResolver
{
    /**
     * @var CustomerCompanyResolver
     */
    private $customerCompanyResolver;

    /**
     * @var CompanyRepositoryInterface
     */
    private $companyRepository;

    public function __construct(
        CustomerCompanyResolver $customerCompanyResolver,
        CompanyRepositoryInterface $companyRepository
    ) {
        $this->customerCompanyResolver = $customerCompanyResolver;
        $this->companyRepository = $companyRepository;
    }

    public function resolveCompanyByCustomerId(int $customerId): ?CompanyInterface
    {
        $companyAttributes = $this->customerCompanyResolver->resolveForCustomerId($customerId);
        if ($companyAttributes === null || !$companyAttributes->getCompanyId()) {
            return null;
        }

        try {
            return $this->companyRepository->getById($companyAttributes->getCompanyId(), true);
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }
}
