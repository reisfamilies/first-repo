<?php





namespace Manh\Chu\Model\Company;

use Manh\Chu\Api\PermissionRepositoryInterface;

class IsResourceAllowed
{
    /**
     * @var PermissionRepositoryInterface
     */
    private $permissionRepository;

    public function __construct(PermissionRepositoryInterface $permissionRepository)
    {
        $this->permissionRepository = $permissionRepository;
    }

    public function checkResourceForRole(string $resource, int $roleId): bool
    {
        $permissions = $this->permissionRepository->getByRoleId($roleId);
        foreach ($permissions->getItems() as $permission) {
            if ($resource === $permission->getResourceId()) {
                return true;
            }
        }

        return false;
    }
}
