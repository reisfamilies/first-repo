<?php





namespace Manh\Chu\Model\Company;

use Manh\Chu\Api\CompanyRepositoryInterface;
use Manh\Chu\Api\Data\CompanyInterface;
use Manh\Chu\Api\Data\CompanyInterfaceFactory;
use Manh\Chu\Model\Company;
use Manh\Chu\Model\CompanyContext;
use Manh\Chu\Model\ConfigProvider;
use Manh\Chu\Model\Source\Company\Status as CompanyStatus;
use Magento\Customer\Model\Context;
use Magento\Framework\App\Http\Context as HttpContext;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Phrase;
use Magento\User\Model\ResourceModel\User\CollectionFactory;

class SaveCompanyData
{
    /**
     * @var InputException|null
     */
    private $exception = null;

    /**
     * @var CompanyRepositoryInterface
     */
    private $companyRepository;

    /**
     * @var CollectionFactory
     */
    private $userCollectionFactory;

    /**
     * @var CompanyContext
     */
    private $companyContext;

    /**
     * @var ConfigProvider
     */
    private $configProvider;

    /**
     * @var HttpContext
     */
    private $httpContext;

    /**
     * @var CompanyInterfaceFactory
     */
    private $companyFactory;

    /**
     * @var FormConfig
     */
    private $formConfig;

    public function __construct(
        CompanyRepositoryInterface $companyRepository,
        CollectionFactory $userCollectionFactory,
        CompanyContext $companyContext,
        ConfigProvider $configProvider,
        HttpContext $httpContext,
        CompanyInterfaceFactory $companyFactory,
        FormConfig $formConfig
    ) {
        $this->companyRepository = $companyRepository;
        $this->userCollectionFactory = $userCollectionFactory;
        $this->companyContext = $companyContext;
        $this->configProvider = $configProvider;
        $this->httpContext = $httpContext;
        $this->companyFactory = $companyFactory;
        $this->formConfig = $formConfig;
    }

    public function saveCompany(array $data): void
    {
        $this->validate($data);
        /** @var Company $company */
        $company = $this->companyFactory->create();
        $company->setData($data);
        $this->prepareCompanyData($company);
        $this->companyRepository->save($company);
    }

    /**
     * Validate form data before save
     *
     * Note: at this stage customer may not exist yet
     *
     * @throws InputException
     */
    public function validate(array $data): void
    {
        foreach ($this->formConfig->getRequiredFormFields() as $requiredField) {
            if (empty($data[$requiredField])) {
                $this->addException(InputException::requiredField($this->formConfig->getLabel($requiredField)));
            }
        }
        $this->validateEmail($data);

        if ($this->exception) {
            $exception = $this->exception;
            $this->exception = null;
            throw $exception;
        }
    }

    private function addException($exception): void
    {
        if (!$this->exception) {
            $this->exception = new InputException();
        }

        $this->exception->addException($exception);
    }

    public function getSuccessMessage(array $data = []): Phrase
    {
        if (isset($data['company_id'])) {
            $message = __('Company Account information was successfully saved.');
        } else {
            $message = $this->configProvider->isAutoApprove()
                ? __('Thank you! New Company Account was created successfully.')
                : __('Thank you! Your request is received and will be reviewed as soon as possible.');
        }

        return $message;
    }

    /**
     * @param CompanyInterface $company
     */
    private function prepareCompanyData(CompanyInterface $company): void
    {
        if (!$company->getCompanyId()) {
            if (!$company->getSuperUserId()) {
                $company->setSuperUserId($this->companyContext->getCurrentCustomerId());
            }
            if (!$company->getCustomerGroupId()) {
                $company->setCustomerGroupId($this->getCurrentCustomerGroupId());
            }
            $this->setStatus($company);
            $userCollection = $this->userCollectionFactory->create();
            $userCollection->getSelect()->limit(1);
            $company->setSalesRepresentativeId($userCollection->getFirstItem()->getId());
        }

        $this->setStreet($company);
    }

    private function getCurrentCustomerGroupId(): int
    {
        return (int)$this->httpContext->getValue(Context::CONTEXT_GROUP);
    }

    private function setStreet(CompanyInterface $company): void
    {
        $street = $company->getStreet();
        if (is_array($street) && count($street)) {
            $company->setStreet(trim(implode("\n", $street)));
        }
    }

    private function setStatus(CompanyInterface $company): void
    {
        if ($this->configProvider->isAutoApprove()) {
            $company->setStatus(CompanyStatus::STATUS_ACTIVE);
        } else {
            $company->setStatus(CompanyStatus::STATUS_PENDING);
        }
    }

    /**
     * @throws InputException
     */
    private function validateEmail(array $data): void
    {
        $email = $data[CompanyInterface::COMPANY_EMAIL] ?? null;
        if (empty($email)) {
            return;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->addException(InputException::invalidFieldValue(__('Company Email'), $email));
            return;
        }
        if (!isset($data[CompanyInterface::COMPANY_ID])
            && $this->isEmailExist($email)
        ) {
            $this->addException(new InputException(
                __(
                    'There is already a company account associated with this email address.'
                    . ' Please enter a different email address.'
                )
            ));
        }
    }

    private function isEmailExist(string $email): bool
    {
        $company = $this->companyRepository->getByField(CompanyInterface::COMPANY_EMAIL, $email);

        return (bool)$company->getCompanyId();
    }
}
