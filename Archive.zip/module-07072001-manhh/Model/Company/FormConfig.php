<?php





namespace Manh\Chu\Model\Company;

use Manh\Chu\Api\Data\CompanyInterface;
use Magento\Framework\Phrase;
use Magento\Framework\View\Element\Block\ArgumentInterface;

class FormConfig implements ArgumentInterface
{
    /**
     * @return string[]
     */
    public function getRequiredFormFields(): array
    {
        return [
            CompanyInterface::COMPANY_NAME,
            CompanyInterface::COMPANY_EMAIL,
            CompanyInterface::STREET,
            CompanyInterface::CITY,
            CompanyInterface::COUNTRY_ID,
            CompanyInterface::TELEPHONE
        ];
    }

    /**
     * @return string[]
     */
    public function getRequiredFields(): array
    {
        return [
            CompanyInterface::COMPANY_NAME,
            CompanyInterface::SUPER_USER_ID,
            CompanyInterface::CUSTOMER_GROUP_ID,
            CompanyInterface::COMPANY_EMAIL,
            CompanyInterface::STREET,
            CompanyInterface::CITY,
            CompanyInterface::COUNTRY_ID,
            CompanyInterface::TELEPHONE
        ];
    }

    /**
     * @return Phrase|string
     * @SuppressWarnings(PHPMD.CyclomaticComplexity) switch is better than array search because of translate execution
     */
    public function getLabel(string $name)
    {
        switch ($name) {
            case CompanyInterface::COMPANY_NAME:
                return __('Company Name');
            case CompanyInterface::COMPANY_EMAIL:
                return __('Company Email');
            case CompanyInterface::STREET:
                return __('Street Address');
            case CompanyInterface::CITY:
                return __('City');
            case CompanyInterface::COUNTRY_ID:
                return __('Country');
            case CompanyInterface::TELEPHONE:
                return __('Phone Number');
            case CompanyInterface::LEGAL_NAME:
                return __('Company Legal Name');
            case CompanyInterface::VAT_TAX_ID:
                return __('VAT/TAX ID');
            case CompanyInterface::RESELLER_ID:
                return __('Re-seller ID');
            case CompanyInterface::REGION_ID:
            case CompanyInterface::REGION:
                return __('State/Province');
            case CompanyInterface::POSTCODE:
                return __('ZIP/Postal Code');
            default:
                return $name;
        }
    }
}
