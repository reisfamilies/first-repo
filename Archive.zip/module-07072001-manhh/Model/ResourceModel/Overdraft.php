<?php





namespace Manh\Chu\Model\ResourceModel;

use Manh\Chu\Api\Data\OverdraftInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Overdraft extends AbstractDb
{
    protected function _construct()
    {
        $this->_init(OverdraftInterface::MAIN_TABLE, OverdraftInterface::ID);
    }
}
