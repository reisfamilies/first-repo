<?php





namespace Manh\Chu\Model\ResourceModel\Permission;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init(
            \Manh\Chu\Model\Permission::class,
            \Manh\Chu\Model\ResourceModel\Permission::class
        );
        $this->_setIdFieldName($this->getResource()->getIdFieldName());
    }
}
