<?php





namespace Manh\Chu\Model\ResourceModel\Credit;

use Manh\Chu\Api\Data\CreditInterface;
use Manh\Chu\Model\Credit as CreditModel;
use Manh\Chu\Model\ResourceModel\Credit as CreditResource;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = CreditInterface::ID;

    protected function _construct()
    {
        $this->_init(CreditModel::class, CreditResource::class);
    }
}
