<?php





namespace Manh\Chu\Model\ResourceModel\Overdraft;

use Manh\Chu\Api\Data\OverdraftInterface;
use Manh\Chu\Model\Overdraft as OverdraftModel;
use Manh\Chu\Model\ResourceModel\Overdraft as OverdraftResource;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = OverdraftInterface::ID;

    protected function _construct()
    {
        $this->_init(OverdraftModel::class, OverdraftResource::class);
    }
}
