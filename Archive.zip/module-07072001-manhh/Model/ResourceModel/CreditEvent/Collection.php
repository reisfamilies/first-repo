<?php





namespace Manh\Chu\Model\ResourceModel\CreditEvent;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Model\CreditEvent as CreditEventModel;
use Manh\Chu\Model\ResourceModel\CreditEvent as CreditEventResource;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = CreditEventInterface::ID;

    protected function _construct()
    {
        $this->_init(CreditEventModel::class, CreditEventResource::class);
    }
}
