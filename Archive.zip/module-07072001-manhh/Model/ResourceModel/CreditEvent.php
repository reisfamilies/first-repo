<?php





namespace Manh\Chu\Model\ResourceModel;

use Manh\Chu\Api\Data\CreditEventInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class CreditEvent extends AbstractDb
{
    protected function _construct()
    {
        $this->_init(CreditEventInterface::MAIN_TABLE, CreditEventInterface::ID);
    }
}
