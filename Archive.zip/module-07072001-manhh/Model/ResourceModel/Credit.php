<?php





namespace Manh\Chu\Model\ResourceModel;

use Manh\Chu\Api\Data\CreditInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Credit extends AbstractDb
{
    protected function _construct()
    {
        $this->_init(CreditInterface::MAIN_TABLE, CreditInterface::ID);
    }
}
