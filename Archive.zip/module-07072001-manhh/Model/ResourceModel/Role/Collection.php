<?php





namespace Manh\Chu\Model\ResourceModel\Role;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init(
            \Manh\Chu\Model\Role::class,
            \Manh\Chu\Model\ResourceModel\Role::class
        );
        $this->_setIdFieldName($this->getResource()->getIdFieldName());
    }
}
