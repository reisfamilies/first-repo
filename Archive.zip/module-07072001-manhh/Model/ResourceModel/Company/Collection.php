<?php





namespace Manh\Chu\Model\ResourceModel\Company;

use Manh\Chu\Api\Data\CompanyInterface;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init(
            \Manh\Chu\Model\Company::class,
            \Manh\Chu\Model\ResourceModel\Company::class
        );
        $this->_setIdFieldName($this->getResource()->getIdFieldName());
    }

    /**
     * @param array $companyIds
     * @return $this
     */
    public function addCompanyIdFilter($companyIds)
    {
        if (!is_array($companyIds)) {
            $companyIds = [$companyIds];
        }

        $this->addFieldToFilter(CompanyInterface::COMPANY_ID, ['in' => $companyIds]);

        return $this;
    }
}
