<?php





namespace Manh\Chu\Model\Repository;

use Manh\Chu\Api\CreditRepositoryInterface;
use Manh\Chu\Api\Data\CreditInterface;
use Manh\Chu\Model\Credit\Command\SaveInterface as CommandSave;
use Manh\Chu\Model\Credit\Query\GetByCompanyIdInterface;
use Manh\Chu\Model\Credit\Query\GetNewInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class CreditRepository implements CreditRepositoryInterface
{
    /**
     * @var GetNewInterface
     */
    private $getNew;

    /**
     * @var GetByCompanyIdInterface
     */
    private $getByCompanyId;

    /**
     * @var CommandSave
     */
    private $commandSave;

    public function __construct(
        GetNewInterface $getNew,
        GetByCompanyIdInterface $getByCompanyId,
        CommandSave $commandSave
    ) {
        $this->getNew = $getNew;
        $this->getByCompanyId = $getByCompanyId;
        $this->commandSave = $commandSave;
    }

    public function getNew(): CreditInterface
    {
        return $this->getNew->execute();
    }

    /**
     * @param int $companyId
     * @return CreditInterface
     * @throws NoSuchEntityException
     */
    public function getByCompanyId(int $companyId): CreditInterface
    {
        return $this->getByCompanyId->execute($companyId);
    }

    /**
     * @param CreditInterface $credit
     * @return void
     * @throws CouldNotSaveException
     */
    public function save(CreditInterface $credit): void
    {
        $this->commandSave->execute($credit);
    }
}
