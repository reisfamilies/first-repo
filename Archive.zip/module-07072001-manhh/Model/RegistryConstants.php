<?php





namespace Manh\Chu\Model;

class RegistryConstants
{
    /**#@+
     * Constants defined for dataPersistor
     */
    public const COMPANY_DATA = 'amcompany_company';
    /**#@-*/
}
