<?php





namespace Manh\Chu\Model\Extensions\Order;

use Manh\Chu\Api\Data\OrderInterfaceFactory;
use Manh\Chu\Model\ResourceModel\Order as OrderResource;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Sales\Api\Data\OrderInterface;
use Psr\Log\LoggerInterface;
use Manh\Chu\Api\Data\OrderInterface as CompanyOrderInterface;

class ExtensionAttributes
{
    /**
     * @var ExtensionAttributesFactory
     */
    private $extensionFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var OrderResource
     */
    private $orderResource;

    /**
     * @var OrderInterfaceFactory
     */
    private $companyOrderFactory;

    /**
     * @var LoggerInterface
     */
    private $logger;

    public function __construct(
        ExtensionAttributesFactory $extensionFactory,
        DataObjectHelper $dataObjectHelper,
        OrderResource $orderResource,
        OrderInterfaceFactory $companyOrderFactory,
        LoggerInterface $logger
    ) {
        $this->extensionFactory = $extensionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->orderResource = $orderResource;
        $this->companyOrderFactory = $companyOrderFactory;
        $this->logger = $logger;
    }

    public function addCompanyAttributes(OrderInterface $order): void
    {
        if ($order->getExtensionAttributes()
            && $order->getExtensionAttributes()->getAmCompanyAttributes()
        ) {
            return;
        }

        if (!$order->getExtensionAttributes()) {
            $orderExtension = $this->extensionFactory->create(OrderInterface::class);
            $order->setExtensionAttributes($orderExtension);
        }

        $companyAttributes = $this->getCompanyAttributes($order);

        if ($companyAttributes) {
            $order->getExtensionAttributes()->setData('amcompany_attributes', $companyAttributes);
        }
    }

    public function getCompanyAttributes(OrderInterface $order): ?CompanyOrderInterface
    {
        $companyAttributesArray = $this->getCompanyAttributesArray((int)$order->getId());
        if (!$companyAttributesArray) {
            return null;
        }
        $companyAttributes = $this->companyOrderFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $companyAttributes,
            $companyAttributesArray,
            CompanyOrderInterface::class
        );
        $companyAttributes->setOrderId($order->getId());

        return $companyAttributes;
    }

    public function getCompanyAttributesArray(int $orderId)
    {
        try {
            $companyAttributesArray = $this->orderResource->getOrderExtensionAttributes($orderId);
        } catch (\Exception $e) {
            $this->logger->error($e->getMessage());
            $companyAttributesArray = [];
        }

        return $companyAttributesArray;
    }
}
