<?php





namespace Manh\Chu\Model\Backend\Company;

use Manh\Chu\Api\Data\CompanyInterface;

class Registry
{
    /**
     * @var CompanyInterface|null
     */
    private $company;

    public function set(CompanyInterface $company): void
    {
        $this->company = $company;
    }

    public function get(): CompanyInterface
    {
        return $this->company;
    }
}
