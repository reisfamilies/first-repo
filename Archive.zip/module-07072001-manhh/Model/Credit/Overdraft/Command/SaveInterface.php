<?php





namespace Manh\Chu\Model\Credit\Overdraft\Command;

use Manh\Chu\Api\Data\OverdraftInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * @api
 */
interface SaveInterface
{
    /**
     * @param OverdraftInterface $overdraft
     * @return void
     * @throws CouldNotSaveException
     */
    public function execute(OverdraftInterface $overdraft): void;
}
