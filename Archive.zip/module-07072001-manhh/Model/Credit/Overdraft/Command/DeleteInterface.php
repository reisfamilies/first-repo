<?php





namespace Manh\Chu\Model\Credit\Overdraft\Command;

use Manh\Chu\Api\Data\OverdraftInterface;
use Magento\Framework\Exception\CouldNotDeleteException;

interface DeleteInterface
{
    /**
     * @param OverdraftInterface $overdraft
     * @return void
     * @throws CouldNotDeleteException
     */
    public function execute(OverdraftInterface $overdraft): void;
}
