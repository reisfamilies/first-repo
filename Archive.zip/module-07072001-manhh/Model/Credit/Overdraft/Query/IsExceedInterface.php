<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

/**
 * @api
 */
interface IsExceedInterface
{
    public function execute(int $creditId): bool;
}
