<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

use Manh\Chu\Api\Data\OverdraftInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * @api
 */
interface GetByCreditIdInterface
{
    /**
     * @param int $creditId
     * @return OverdraftInterface
     * @throws NoSuchEntityException
     */
    public function execute(int $creditId): OverdraftInterface;
}
