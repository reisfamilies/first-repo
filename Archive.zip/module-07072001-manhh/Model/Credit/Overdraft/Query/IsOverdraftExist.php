<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

use Manh\Chu\Model\Credit\Overdraft\Query\GetByCreditIdInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class IsOverdraftExist implements IsOverdraftExistInterface
{
    /**
     * @var GetByCreditIdInterface
     */
    private $getByCreditId;

    public function __construct(GetByCreditIdInterface $getByCreditId)
    {
        $this->getByCreditId = $getByCreditId;
    }

    public function execute(int $creditId): bool
    {
        try {
            $this->getByCreditId->execute($creditId);
            $result = true;
        } catch (NoSuchEntityException $e) {
            $result = false;
        }

        return $result;
    }
}
