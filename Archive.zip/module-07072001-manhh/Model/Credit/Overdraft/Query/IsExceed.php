<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

use Manh\Chu\Model\ResourceModel\Overdraft\IsOverdraftExceed;

class IsExceed implements IsExceedInterface
{
    /**
     * @var IsOverdraftExceed
     */
    private $isOverdraftExceed;

    public function __construct(IsOverdraftExceed $isOverdraftExceed)
    {
        $this->isOverdraftExceed = $isOverdraftExceed;
    }

    public function execute(int $creditId): bool
    {
        return $this->isOverdraftExceed->execute($creditId);
    }
}
