<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

use Manh\Chu\Api\Data\OverdraftInterface;

/**
 * @api
 */
interface GetNewInterface
{
    public function execute(): OverdraftInterface;
}
