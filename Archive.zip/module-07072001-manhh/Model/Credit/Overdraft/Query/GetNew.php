<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

use Manh\Chu\Api\Data\OverdraftInterface;
use Manh\Chu\Api\Data\OverdraftInterfaceFactory;

class GetNew implements GetNewInterface
{
    /**
     * @var OverdraftInterfaceFactory
     */
    private $overdraftInterfaceFactory;

    public function __construct(OverdraftInterfaceFactory $overdraftInterfaceFactory)
    {
        $this->overdraftInterfaceFactory = $overdraftInterfaceFactory;
    }

    public function execute(): OverdraftInterface
    {
        return $this->overdraftInterfaceFactory->create();
    }
}
