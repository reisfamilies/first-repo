<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

use Manh\Chu\Api\Data\OverdraftInterface;
use Manh\Chu\Api\Data\OverdraftInterfaceFactory;
use Manh\Chu\Model\ResourceModel\Overdraft as OverdraftResource;
use Magento\Framework\Exception\NoSuchEntityException;

class GetByCreditId implements GetByCreditIdInterface
{
    /**
     * @var OverdraftInterfaceFactory
     */
    private $overdraftFactory;

    /**
     * @var OverdraftResource
     */
    private $overdraftResource;

    public function __construct(
        OverdraftInterfaceFactory $overdraftFactory,
        OverdraftResource $overdraftResource
    ) {
        $this->overdraftFactory = $overdraftFactory;
        $this->overdraftResource = $overdraftResource;
    }

    /**
     * @param int $creditId
     * @return OverdraftInterface
     * @throws NoSuchEntityException
     */
    public function execute(int $creditId): OverdraftInterface
    {
        /** @var OverdraftInterface $overdraft */
        $overdraft = $this->overdraftFactory->create();
        $this->overdraftResource->load($overdraft, $creditId, OverdraftInterface::CREDIT_ID);

        if ($overdraft->getId() === null) {
            throw new NoSuchEntityException(
                __('Overdraft with credit id "%value" does not exist.', ['value' => $creditId])
            );
        }

        return $overdraft;
    }
}
