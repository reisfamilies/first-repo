<?php





namespace Manh\Chu\Model\Credit\Overdraft\Query;

/**
 * @api
 */
interface IsOverdraftExistInterface
{
    public function execute(int $creditId): bool;
}
