<?php





namespace Manh\Chu\Model\Credit\Query;

use Manh\Chu\Api\Data\CreditInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class GetByCompanyIdCache implements GetByCompanyIdInterface
{
    /**
     * @var array
     */
    private $credits = [];

    /**
     * @var GetByCompanyId
     */
    private $getByCompanyId;

    public function __construct(GetByCompanyId $getByCompanyId)
    {
        $this->getByCompanyId = $getByCompanyId;
    }

    /**
     * @param int $companyId
     * @return CreditInterface
     * @throws NoSuchEntityException
     */
    public function execute(int $companyId): CreditInterface
    {
        if (!isset($this->credits[$companyId])) {
            $this->credits[$companyId] = $this->getByCompanyId->execute($companyId);
        }

        return $this->credits[$companyId];
    }
}
