<?php





namespace Manh\Chu\Model\Credit\Query;

use Manh\Chu\Model\ResourceModel\CreditEvent\Collection as CreditEventCollection;

interface GetEventsByCreditIdInterface
{
    public function execute(int $creditId): CreditEventCollection;
}
