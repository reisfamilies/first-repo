<?php





namespace Manh\Chu\Model\Credit\Query;

use Manh\Chu\Api\Data\CreditInterface;

/**
 * @api
 */
interface GetNewInterface
{
    public function execute(): CreditInterface;
}
