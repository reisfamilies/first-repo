<?php





namespace Manh\Chu\Model\Credit\Query;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Model\ResourceModel\CreditEvent\Collection as CreditEventCollection;
use Manh\Chu\Model\ResourceModel\CreditEvent\CollectionFactory;

class GetEventsByCreditId implements GetEventsByCreditIdInterface
{
    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    public function __construct(CollectionFactory $collectionFactory)
    {
        $this->collectionFactory = $collectionFactory;
    }

    public function execute(int $creditId): CreditEventCollection
    {
        $collection = $this->collectionFactory->create();
        $collection->addFieldToFilter(CreditEventInterface::CREDIT_ID, $creditId);
        return $collection;
    }
}
