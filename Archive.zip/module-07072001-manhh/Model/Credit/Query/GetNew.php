<?php





namespace Manh\Chu\Model\Credit\Query;

use Manh\Chu\Api\Data\CreditInterface;
use Manh\Chu\Api\Data\CreditInterfaceFactory;

class GetNew implements GetNewInterface
{
    /**
     * @var CreditInterfaceFactory
     */
    private $creditFactory;

    public function __construct(CreditInterfaceFactory $creditFactory)
    {
        $this->creditFactory = $creditFactory;
    }

    public function execute(): CreditInterface
    {
        return $this->creditFactory->create();
    }
}
