<?php





namespace Manh\Chu\Model\Credit\Query;

use Manh\Chu\Api\Data\CreditInterface;
use Magento\Framework\Exception\NoSuchEntityException;

interface GetByIdInterface
{
    /**
     * @param int $id
     * @return CreditInterface
     * @throws NoSuchEntityException
     */
    public function execute(int $id): CreditInterface;
}
