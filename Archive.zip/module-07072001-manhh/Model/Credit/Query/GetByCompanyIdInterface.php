<?php





namespace Manh\Chu\Model\Credit\Query;

use Manh\Chu\Api\Data\CreditInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * @api
 */
interface GetByCompanyIdInterface
{
    /**
     * @param int $companyId
     * @return CreditInterface
     * @throws NoSuchEntityException
     */
    public function execute(int $companyId): CreditInterface;
}
