<?php





namespace Manh\Chu\Model\Credit\Event\Condition;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Api\Data\CreditInterface;
use Magento\Framework\Phrase;
use Magento\Framework\Validation\ValidationException;

interface ConditionInterface
{
    /**
     * @param CreditInterface $credit
     * @param CreditEventInterface $creditEvent
     * @return void
     * @throws ValidationException
     */
    public function validate(CreditInterface $credit, CreditEventInterface $creditEvent): void;
}
