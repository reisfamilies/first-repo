<?php





namespace Manh\Chu\Model\Credit\Event;

use Manh\Chu\Api\Data\CreditEventInterface;

/**
 * Retrieve amount in display currency.
 */
class RetrieveAmount
{
    public function execute(CreditEventInterface $creditEvent): float
    {
        $amount = $creditEvent->getAmount();
        if ($creditEvent->getRate()) {
            $amount *= $creditEvent->getRate();
        }

        return $amount;
    }
}
