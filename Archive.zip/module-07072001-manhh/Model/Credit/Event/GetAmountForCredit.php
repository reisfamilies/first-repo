<?php





namespace Manh\Chu\Model\Credit\Event;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Model\Price\Convert as ConvertPrice;

class GetAmountForCredit
{
    /**
     * @var ConvertPrice
     */
    private $convertPrice;

    public function __construct(ConvertPrice $convertPrice)
    {
        $this->convertPrice = $convertPrice;
    }

    /**
     * Calculate operation amount in Credit Entity Currency.
     *
     * @param CreditEventInterface $creditEvent
     * @return float
     */
    public function execute(CreditEventInterface $creditEvent): float
    {
        return $this->convertPrice->execute(
            $creditEvent->getAmount(),
            $creditEvent->getCurrencyEvent(),
            $creditEvent->getCurrencyCredit()
        );
    }
}
