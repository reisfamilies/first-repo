<?php





namespace Manh\Chu\Model\Credit\Event;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Model\Credit\Event\Comment\FormatComments;

class RetrieveComments
{
    /**
     * @var FormatComments
     */
    private $formatComments;

    public function __construct(FormatComments $formatComments)
    {
        $this->formatComments = $formatComments;
    }

    public function execute(CreditEventInterface $creditEvent): string
    {
        $result = '';
        if ($creditEvent->getComment()) {
            $result = $this->formatComments->execute($creditEvent->getComment());
        }

        return $result;
    }
}
