<?php





namespace Manh\Chu\Model\Credit\Event\Action;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Api\Data\CreditInterface;

interface ChangeCreditStrategyInterface
{
    public function execute(CreditInterface $credit, CreditEventInterface $creditEvent): void;
}
