<?php





namespace Manh\Chu\Model\Credit\Event\Action;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Api\Data\CreditInterface;
use Manh\Chu\Model\Credit\Event\GetAmountForCredit;

class DefaultStrategy implements ChangeCreditStrategyInterface
{
    /**
     * @var GetAmountForCredit
     */
    private $getAmountForCredit;

    public function __construct(GetAmountForCredit $getAmountForCredit)
    {
        $this->getAmountForCredit = $getAmountForCredit;
    }

    public function execute(CreditInterface $credit, CreditEventInterface $creditEvent): void
    {
        $amount = $this->getAmountForCredit->execute($creditEvent);

        $newBalance = $credit->getBalance() + $amount;
        $creditEvent->setBalance($newBalance);
        $credit->setBalance($newBalance);
    }
}
