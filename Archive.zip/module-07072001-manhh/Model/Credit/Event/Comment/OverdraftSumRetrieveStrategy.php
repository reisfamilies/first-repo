<?php





namespace Manh\Chu\Model\Credit\Event\Comment;

class OverdraftSumRetrieveStrategy implements RetrieveStrategyInterface
{
    public function execute(string $value): string
    {
        return __('Overdraft used: %1', $value)->render();
    }
}
