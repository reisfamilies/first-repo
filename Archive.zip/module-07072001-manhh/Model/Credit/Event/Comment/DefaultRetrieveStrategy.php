<?php





namespace Manh\Chu\Model\Credit\Event\Comment;

class DefaultRetrieveStrategy implements RetrieveStrategyInterface
{
    public function execute(string $value): string
    {
        return $value;
    }
}
