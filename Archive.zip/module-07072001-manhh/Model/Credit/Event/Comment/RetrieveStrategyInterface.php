<?php





namespace Manh\Chu\Model\Credit\Event\Comment;

interface RetrieveStrategyInterface
{
    public function execute(string $value): string;
}
