<?php





namespace Manh\Chu\Model\Credit\Event\Query;

use Manh\Chu\Model\ResourceModel\CreditEvent\GetEventsCount as GetEventsCountResource;

class GetEventsCount implements GetEventsCountInterface
{
    /**
     * @var GetEventsCountResource
     */
    private $getEventsCountResource;

    public function __construct(GetEventsCountResource $getEventsCountResource)
    {
        $this->getEventsCountResource = $getEventsCountResource;
    }

    public function execute(int $creditId, ?string $eventType = null): int
    {
        return $this->getEventsCountResource->execute($creditId, $eventType);
    }
}
