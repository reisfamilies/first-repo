<?php





namespace Manh\Chu\Model\Credit\Event\Query;

use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Api\Data\CreditEventInterfaceFactory;
use Magento\Framework\Serialize\Serializer\Json;

class CreateCreditEvent implements CreateCreditEventInterface
{
    /**
     * @var CreditEventInterfaceFactory
     */
    private $creditEventFactory;

    /**
     * @var Json
     */
    private $jsonSerializer;

    public function __construct(
        CreditEventInterfaceFactory $creditEventFactory,
        Json $jsonSerializer
    ) {
        $this->creditEventFactory = $creditEventFactory;
        $this->jsonSerializer = $jsonSerializer;
    }

    public function execute(array $data): CreditEventInterface
    {
        if (isset($data[CreditEventInterface::COMMENT]) && is_array($data[CreditEventInterface::COMMENT])) {
            $data[CreditEventInterface::COMMENT] = $this->jsonSerializer->serialize(
                $data[CreditEventInterface::COMMENT]
            );
        }

        return $this->creditEventFactory->create(['data' => $data]);
    }
}
