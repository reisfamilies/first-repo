<?php





namespace Manh\Chu\Model\Credit\Event\Query;

/**
 * @api
 */
interface GetEventsCountInterface
{
    public function execute(int $creditId, ?string $eventType = null): int;
}
