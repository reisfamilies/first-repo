<?php





namespace Manh\Chu\Model\Credit\Event\Query;

use Manh\Chu\Api\Data\CreditEventInterface;

/**
 * @api
 */
interface CreateCreditEventInterface
{
    public function execute(array $data): CreditEventInterface;
}
