<?php





namespace Manh\Chu\Model\Credit\Command;

use Manh\Chu\Api\Data\CreditInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * @api
 */
interface SaveInterface
{
    /**
     * @param CreditInterface $credit
     * @return void
     * @throws CouldNotSaveException
     */
    public function execute(CreditInterface $credit): void;
}
