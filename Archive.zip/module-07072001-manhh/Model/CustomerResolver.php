<?php





namespace Manh\Chu\Model;

use Magento\Customer\Model\Session;

class CustomerResolver
{
    /**
     * @var Session
     */
    private $customerSession;

    public function __construct(Session $customerSession)
    {
        $this->customerSession = $customerSession;
    }

    /**
     * Return logged customer ID
     *
     * Note: worked only if page has disabled "Full Page Cache".
     * Because FPC depersonalize session data
     */
    public function getCustomerId(): ?int
    {
        $customerId = $this->customerSession->getCustomerId();
        if ($customerId === null) {
            return null;
        }

        return (int)$customerId;
    }

    public function getCustomerGroupId(): int
    {
        return (int)$this->customerSession->getCustomerGroupId();
    }
}
