<?php





namespace Manh\Chu\Ui\DataProvider\CreditEvent;

use Manh\Chu\Api\Data\CreditEventInterface;

class DataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider
{
    public function getSearchCriteria()
    {
        if (!$this->searchCriteria) {
            $creditId = (int) $this->request->getParam(CreditEventInterface::CREDIT_ID);
            $this->filterBuilder->setField(CreditEventInterface::CREDIT_ID);
            $this->filterBuilder->setValue($creditId);
            $this->addFilter($this->filterBuilder->create());
        }

        return parent::getSearchCriteria();
    }
}
