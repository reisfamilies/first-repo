<?php





namespace Manh\Chu\Ui\Component\Company\Form;

use Manh\Base\Model\ModuleInfoProvider;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Form\Field;

class RestrictedPayments extends Field
{
    /**
     * @var ModuleInfoProvider
     */
    private $moduleInfoProvider;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        ModuleInfoProvider $moduleInfoProvider,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->moduleInfoProvider = $moduleInfoProvider;
    }

    public function prepare()
    {
        parent::prepare();
        $config = $this->getData('config');
        if ($this->moduleInfoProvider->isOriginMarketplace()) {
            unset($config['additionalInfo']);
        } else {
            $label = __('Payment Restrictions')->render();
            $href = 'https://manh.com/payment-restrictions-for-magento-2.html' .
                '?utm_source=demo&utm_medium=gotopage&utm_campaign=company_to_restriction_m2';
            $link = sprintf(
                '<a href="%s" target="_blank">%s</a>',
                $href,
                $label
            );
            $config['additionalInfo'] =
                __("For advanced configuration you can use %1 extension.", $link)->render();
        }

        $this->setData('config', $config);
    }
}
