<?php





namespace Manh\Chu\Ui\Component\Company\Form;

use Manh\Chu\Api\Data\CreditInterface;
use Manh\Chu\Model\Backend\Company\Registry as CompanyRegistry;
use Manh\Chu\Model\Price\Format as FormatPrice;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Form\Field;

/**
 * Need be used for credit cards.
 * Expected that current editable company in CompanyRegistry.
 * @see \Manh\Chu\Model\Backend\Company\Registry
 */
abstract class PriceField extends Field
{
    /**
     * @var CompanyRegistry
     */
    private $companyRegistry;

    /**
     * @var FormatPrice
     */
    private $formatPrice;

    public function __construct(
        CompanyRegistry $companyRegistry,
        FormatPrice $formatPrice,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->companyRegistry = $companyRegistry;
        $this->formatPrice = $formatPrice;
    }

    protected function formatPrice(float $price): string
    {
        return $this->formatPrice->execute($price, $this->getCredit()->getCurrencyCode());
    }

    private function getCredit(): CreditInterface
    {
        return $this->companyRegistry->get()->getExtensionAttributes()->getCredit();
    }
}
