<?php





namespace Manh\Chu\Api;

/**
 * @api
 */
interface CreditRepositoryInterface
{
    /**
     * @return \Manh\Chu\Api\Data\CreditInterface
     */
    public function getNew(): \Manh\Chu\Api\Data\CreditInterface;

    /**
     * @param int $companyId
     * @return \Manh\Chu\Api\Data\CreditInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getByCompanyId(int $companyId): \Manh\Chu\Api\Data\CreditInterface;

    /**
     * @param \Manh\Chu\Api\Data\CreditInterface $credit
     * @return void
     */
    public function save(\Manh\Chu\Api\Data\CreditInterface $credit): void;
}
