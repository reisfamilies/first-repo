<?php


namespace Manh\Chu\Api;

use Manh\Chu\Model\ResourceModel\Permission\Collection;

/**
 * @api
 */
interface PermissionRepositoryInterface
{
    /**
     * Save
     *
     * @param \Manh\Chu\Api\Data\PermissionInterface $permission
     *
     * @return \Manh\Chu\Api\Data\PermissionInterface
     */
    public function save(\Manh\Chu\Api\Data\PermissionInterface $permission);

    /**
     * @param array $data
     * @return bool true on success
     */
    public function multipleSave(array $data);

    /**
     * @param int $roleId
     * @return Collection
     */
    public function getByRoleId(int $roleId);

    /**
     * Get by id
     *
     * @param int $permissionId
     *
     * @return \Manh\Chu\Api\Data\PermissionInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($permissionId);

    /**
     * Delete
     *
     * @param \Manh\Chu\Api\Data\PermissionInterface $permission
     *
     * @return bool true on success
     * @throws \Magento\Framework\Exception\CouldNotDeleteException
     */
    public function delete(\Manh\Chu\Api\Data\PermissionInterface $permission);

    /**
     * Delete by id
     *
     * @param int $permissionId
     *
     * @return bool true on success
     * @throws \Magento\Framework\Exception\CouldNotDeleteException
     */
    public function deleteById($permissionId);

    /**
     * Lists
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     *
     * @return \Magento\Framework\Api\SearchResultsInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);
}
