<?php





namespace Manh\Chu\Api;

/**
 * @api
 */
interface OverdraftRepositoryInterface
{
    /**
     * @return \Manh\Chu\Api\Data\OverdraftInterface
     */
    public function getNew(): \Manh\Chu\Api\Data\OverdraftInterface;

    /**
     * @param int $creditId
     * @return \Manh\Chu\Api\Data\OverdraftInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getByCreditId(int $creditId): \Manh\Chu\Api\Data\OverdraftInterface;

    /**
     * @param \Manh\Chu\Api\Data\OverdraftInterface $overdraft
     * @return void
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function save(\Manh\Chu\Api\Data\OverdraftInterface $overdraft): void;

    /**
     * @param \Manh\Chu\Api\Data\OverdraftInterface $overdraft
     * @return void
     * @throws \Magento\Framework\Exception\CouldNotDeleteException
     */
    public function delete(\Manh\Chu\Api\Data\OverdraftInterface $overdraft): void;

    /**
     * @param int $creditId
     * @return bool
     */
    public function isExistForCredit(int $creditId): bool;

    /**
     * @param int $creditId
     * @return bool
     */
    public function isOverdraftExceed(int $creditId): bool;
}
