<?php


namespace Manh\Chu\Api\Data;

interface RoleInterface extends RoleExtensionInterface
{
    public const TABLE_NAME = 'manh_company_account_role';
    public const ROLE_ID = 'role_id';
    public const ROLE_NAME = 'role_name';
    public const COMPANY_ID = 'company_id';
    public const ROLE_TYPE_ID = 'role_type_id';

    /**
     * @return int
     */
    public function getRoleId();

    /**
     * @param int $roleId
     *
     * @return \Manh\Chu\Api\Data\RoleInterface
     */
    public function setRoleId($roleId);

    /**
     * @return string|null
     */
    public function getRoleName();

    /**
     * @param string|null $roleName
     *
     * @return \Manh\Chu\Api\Data\RoleInterface
     */
    public function setRoleName($roleName);

    /**
     * @return int
     */
    public function getCompanyId();

    /**
     * @param int $companyId
     *
     * @return \Manh\Chu\Api\Data\RoleInterface
     */
    public function setCompanyId($companyId);

    /**
     * @return int
     */
    public function getRoleTypeId();

    /**
     * @param int $roleId
     *
     * @return \Manh\Chu\Api\Data\RoleInterface
     */
    public function setRoleTypeId($roleId);

    /**
     * @return \Manh\Chu\Api\Data\RoleExtensionInterface
     */
    public function getExtensionAttributes();

    /**
     * @param \Manh\Chu\Api\Data\RoleExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(\Manh\Chu\Api\Data\RoleExtensionInterface $extensionAttributes);
}
