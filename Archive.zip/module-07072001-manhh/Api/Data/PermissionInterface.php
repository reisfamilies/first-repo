<?php


namespace Manh\Chu\Api\Data;

interface PermissionInterface
{
    public const TABLE_NAME = 'manh_company_account_permission';
    public const PERMISSION_ID = 'permission_id';
    public const ROLE_ID = 'role_id';
    public const RESOURCE_ID = 'resource_id';

    /**
     * @return int
     */
    public function getPermissionId();

    /**
     * @param int $permissionId
     *
     * @return \Manh\Chu\Api\Data\PermissionInterface
     */
    public function setPermissionId($permissionId);

    /**
     * @return int
     */
    public function getRoleId();

    /**
     * @param int $roleId
     *
     * @return \Manh\Chu\Api\Data\PermissionInterface
     */
    public function setRoleId($roleId);

    /**
     * @return string
     */
    public function getResourceId();

    /**
     * @param string $resourceId
     *
     * @return \Manh\Chu\Api\Data\PermissionInterface
     */
    public function setResourceId($resourceId);
}
