<?php


namespace Manh\Chu\Api\Data;

/**
 * @api
 */
interface RoleExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{

}
