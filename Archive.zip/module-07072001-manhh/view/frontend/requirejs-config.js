var config = {
    map: {
        '*': {
            'formValidator' : 'Manh_chu/js/formValidator',
            'amcompanyPrompt' : 'Manh_chu/js/prompt',
            'emailValidator' : 'Manh_chu/js/form/element/emailValidator',
            'amaclTree': 'Manh_chu/js/lib/jstree',
            'aclTree': 'Manh_chu/js/acl-tree',
            'amcompanyRegionUpdater': 'Manh_chu/js/region-updater'
        }
    },
    config: {
        mixins: {
            'mage/validation': {
                'Manh_chu/js/validation': true
            }
        }
    }
};
