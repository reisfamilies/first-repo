<?php





namespace Manh\Chu\Plugin\Groupcat\Model\Rule\Condition\Customer\Combine;

use Manh\Chu\Model\Condition\Company as CompanyCondition;
use Manh\Groupcat\Model\Rule\Condition\Customer\Combine;

class AddCompanyCondition
{
    public function afterGetNewChildSelectOptions(Combine $subject, array $result): array
    {
        $attributes = array_pop($result);
        if (isset($attributes['value'])) {
            $attributes['value'][] = [
                'label' => __('Company'),
                'value' => CompanyCondition::class
            ];
            $result[] = $attributes;
        }

        return $result;
    }
}
