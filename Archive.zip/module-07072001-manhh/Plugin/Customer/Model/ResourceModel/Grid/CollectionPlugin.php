<?php





namespace Manh\Chu\Plugin\Customer\Model\ResourceModel\Grid;

use Manh\Chu\Api\Data\CompanyInterface;
use Magento\Customer\Model\ResourceModel\Grid\Collection;

class CollectionPlugin
{
    public function beforeAddFieldToFilter(Collection $subject, $field, $condition = null): array
    {
        if ($field == CompanyInterface::COMPANY_NAME) {
            $field = 'manh_company_account.' . $field;
        }

        if ($field == 'main_table.' . CompanyInterface::COMPANY_NAME) {
            $field = 'manh_company_account.' . CompanyInterface::COMPANY_NAME;
        }

        return [$field, $condition];
    }
}
