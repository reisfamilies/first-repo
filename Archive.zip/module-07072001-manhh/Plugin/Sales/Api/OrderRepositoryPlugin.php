<?php





namespace Manh\Chu\Plugin\Sales\Api;

use Manh\Chu\Api\Data\OrderInterface as AmOrderInterface;
use Manh\Chu\Model\CompanyContext;
use Manh\Chu\Model\CustomerDataProvider;
use Manh\Chu\Model\Extensions\Order\ExtensionAttributes;
use Manh\Chu\Model\ResourceModel\Order as CompanyAccountOrder;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

class OrderRepositoryPlugin
{
    /**
     * @var CompanyAccountOrder
     */
    private $order;

    /**
     * @var CompanyContext
     */
    private $companyContext;

    /**
     * @var CustomerDataProvider
     */
    private $customerDataProvider;

    /**
     * @var ExtensionAttributes
     */
    private $extensionAttributes;

    public function __construct(
        CompanyAccountOrder $order,
        CompanyContext $companyContext,
        CustomerDataProvider $customerDataProvider,
        ExtensionAttributes $extensionAttributes
    ) {
        $this->order = $order;
        $this->companyContext = $companyContext;
        $this->customerDataProvider = $customerDataProvider;
        $this->extensionAttributes = $extensionAttributes;
    }

    /**
     * @param OrderRepositoryInterface $subject
     * @param OrderInterface $order
     * @return OrderInterface
     */
    public function afterGet(OrderRepositoryInterface $subject, OrderInterface $order)
    {
        $this->extensionAttributes->addCompanyAttributes($order);

        return $order;
    }

    public function afterSave(OrderRepositoryInterface $subject, OrderInterface $order): OrderInterface
    {
        $customerId = $order->getCustomerId();

        if (!$customerId) {
            return $order;
        }

        if ($order->getExtensionAttributes()
            && ($newCompanyData = $order->getExtensionAttributes()->getAmcompanyAttributes())
        ) {
            $company = $this->companyContext->getCurrentCompany();

            if (!$company->getCompanyId()) {
                $company = $this->customerDataProvider->getCompanyByCustomerId((int)$customerId);
            }

            if (!$company) {
                return $order;
            }

            if ((int)$newCompanyData->getCompanyId() !== (int)$company->getCompanyId()) {
                throw new LocalizedException(__('Customer is not a company user.'));
            }

            if (null !== $newCompanyData->getCompanyId()) {
                $this->order->saveData([
                    AmOrderInterface::COMPANY_ORDER_ID => $order->getId(),
                    AmOrderInterface::COMPANY_ID => (int)$company->getCompanyId(),
                    AmOrderInterface::COMPANY_NAME => $company->getCompanyName()
                ]);
                $companyAttributes = $this->extensionAttributes->getCompanyAttributes($order);

                if ($companyAttributes) {
                    $order->getExtensionAttributes()->setData('amcompany_attributes', $companyAttributes);
                }
            } else {
                // delete order-company relation if empty company_is is not set.
                $this->order->deleteByOrderId($order->getId());
            }
        }

        return $order;
    }
}
