<?php





namespace Manh\Chu\Plugin\Sales\Model\Service;

use Manh\Chu\Api\Data\OrderInterface as AmOrderInterface;
use Manh\Chu\Model\CompanyContext;
use Manh\Chu\Model\CustomerDataProvider;
use Manh\Chu\Model\Extensions\Order\ExtensionAttributes;
use Manh\Chu\Model\ResourceModel\Order as CompanyAccountOrder;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Service\OrderService;

class OrderServicePlugin
{
    /**
     * @var CompanyAccountOrder
     */
    private $order;

    /**
     * @var CompanyContext
     */
    private $companyContext;

    /**
     * @var CustomerDataProvider
     */
    private $customerDataProvider;

    /**
     * @var ExtensionAttributes
     */
    private $extensionAttributes;

    public function __construct(
        CompanyAccountOrder $order,
        CompanyContext $companyContext,
        CustomerDataProvider $customerDataProvider,
        ExtensionAttributes $extensionAttributes
    ) {
        $this->order = $order;
        $this->companyContext = $companyContext;
        $this->customerDataProvider = $customerDataProvider;
        $this->extensionAttributes = $extensionAttributes;
    }

    public function afterPlace(OrderService $subject, OrderInterface $order): OrderInterface
    {
        $customerId = $order->getCustomerId();
        if (!$customerId) {
            return $order;
        }

        $company = $this->companyContext->getCurrentCompany();
        if (!$company->getCompanyId()) {
            $company = $this->customerDataProvider->getCompanyByCustomerId((int)$customerId);
        }

        if (!$company) {
            return $order;
        }

        $this->order->saveData([
            AmOrderInterface::COMPANY_ORDER_ID => $order->getId(),
            AmOrderInterface::COMPANY_ID => $company->getCompanyId(),
            AmOrderInterface::COMPANY_NAME => $company->getCompanyName()
        ]);
        $this->extensionAttributes->addCompanyAttributes($order);

        return $order;
    }
}
