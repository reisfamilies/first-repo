<?php





namespace Manh\Chu\Plugin\Sales\Controller\AbstractController;

use Manh\Chu\Model\CompanyContext;
use Magento\Customer\Api\CustomerRepositoryInterface;
use \Magento\Sales\Controller\AbstractController\OrderViewAuthorization;
use \Magento\Sales\Model\Order;

class OrderViewAuthorizationPlugin
{
    /**
     * @var CompanyContext
     */
    private $companyContext;

    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var \Manh\Chu\Model\ResourceModel\Order
     */
    private $orderModel;

    public function __construct(
        CompanyContext $companyContext,
        CustomerRepositoryInterface $customerRepository,
        \Manh\Chu\Model\ResourceModel\Order $orderModel
    ) {
        $this->companyContext = $companyContext;
        $this->customerRepository = $customerRepository;
        $this->orderModel = $orderModel;
    }

    /**
     * @param OrderViewAuthorization $subject
     * @param bool $result
     * @param Order $order
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function afterCanView(OrderViewAuthorization $subject, bool $result, Order $order)
    {
        if (!$result) {
            $company = $this->orderModel->getCompanyIdByOrder((int) $order->getEntityId());
            $currentCompany = $this->companyContext->getCurrentCompany()->getCompanyId();

            return $company && $company == $currentCompany;
        }

        return $result;
    }
}
