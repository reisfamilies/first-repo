<?php





namespace Manh\Chu\Setup\Patch\Data;

use Manh\Chu\Api\Data\CompanyInterface;
use Manh\Chu\Api\Data\CustomerInterface;
use Manh\Chu\Api\Data\OrderInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Sales\Api\Data\OrderInterface as SalesOrder;

class InsertCompanyOrders implements DataPatchInterface
{
    private const SALES_ORDER_TABLE = 'sales_order';

    /**
     * @var ResourceConnection
     */
    private $resourceConnection;

    public function __construct(
        ResourceConnection $resourceConnection
    ) {
        $this->resourceConnection = $resourceConnection;
    }

    public function apply(): self
    {
        $connection = $this->resourceConnection->getConnection();
        $orderTable = $this->resourceConnection->getTableName(self::SALES_ORDER_TABLE);
        $companyOrdersTable = $this->resourceConnection->getTableName(OrderInterface::TABLE_NAME);
        $companyOrdersSelect = $connection->select()->from($companyOrdersTable);

        if (!$connection->fetchRow($companyOrdersSelect)) {
            $select = $connection->select()
                ->from($orderTable, [OrderInterface::COMPANY_ORDER_ID => SalesOrder::ENTITY_ID])
                ->joinInner(
                    ['customer' => $this->resourceConnection->getTableName(CustomerInterface::TABLE_NAME)],
                    sprintf(
                        '%s.%s = customer.%s',
                        $orderTable,
                        SalesOrder::CUSTOMER_ID,
                        CustomerInterface::CUSTOMER_ID
                    ),
                    [CustomerInterface::COMPANY_ID]
                )
                ->joinInner(
                    ['company' => $this->resourceConnection->getTableName(CompanyInterface::TABLE_NAME)],
                    sprintf(
                        'customer.%s = company.%s',
                        CustomerInterface::COMPANY_ID,
                        CompanyInterface::COMPANY_ID
                    ),
                    [CompanyInterface::COMPANY_NAME]
                );

            if ($data = $connection->fetchAll($select)) {
                $connection->insertOnDuplicate(
                    $this->resourceConnection->getTableName(OrderInterface::TABLE_NAME),
                    $data
                );
            }
        }

        return $this;
    }

    public function getAliases(): array
    {
        return [];
    }

    public static function getDependencies(): array
    {
        return [];
    }
}
