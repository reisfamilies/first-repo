<?php





namespace Manh\Chu\Setup;

use Manh\Chu\Api\Data\CompanyInterface;
use Manh\Chu\Api\Data\CreditEventInterface;
use Manh\Chu\Api\Data\CreditInterface;
use Manh\Chu\Api\Data\CustomerInterface;
use Manh\Chu\Api\Data\OrderInterface;
use Manh\Chu\Api\Data\OverdraftInterface;
use Manh\Chu\Api\Data\PermissionInterface;
use Manh\Chu\Api\Data\RoleInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

class Uninstall implements UninstallInterface
{
    public const TABLES_TO_DROP = [
        CompanyInterface::TABLE_NAME,
        CustomerInterface::TABLE_NAME,
        RoleInterface::TABLE_NAME,
        PermissionInterface::TABLE_NAME,
        OrderInterface::TABLE_NAME,
        CreditEventInterface::MAIN_TABLE,
        CreditInterface::MAIN_TABLE,
        OverdraftInterface::MAIN_TABLE
    ];

    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context): void
    {
        $this->uninstallTables($setup);
        $this->uninstallConfigData($setup);
    }

    private function uninstallTables(SchemaSetupInterface $setup): void
    {
        foreach (self::TABLES_TO_DROP as $table) {
            $setup->getConnection()->dropTable(
                $setup->getTable($table)
            );
        }
    }

    private function uninstallConfigData(SchemaSetupInterface $setup): void
    {
        $configTable = $setup->getTable('core_config_data');
        $setup->getConnection()->delete($configTable, "`path` LIKE 'manh_companyaccount%'");
    }
}
