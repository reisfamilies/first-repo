<?php





namespace Manh\Chu\ViewModel;

use Magento\Framework\Escaper;
use Magento\Framework\View\Element\Block\ArgumentInterface;

class ElementIdResolver implements ArgumentInterface
{
    /**
     * @var array
     */
    private $elementIds = [];

    /**
     * @var Escaper
     */
    private $escaper;

    public function __construct(Escaper $escaper)
    {
        $this->escaper = $escaper;
    }

    public function getUidHtml(string $elementId): string
    {
        if (!isset($this->elementIds[$elementId])) {
            $this->elementIds[$elementId] = $this->escaper->escapeHtmlAttr(uniqid($elementId . '_', false));
        }

        return $this->elementIds[$elementId];
    }

    public function clear(): void
    {
        $this->elementIds = [];
    }
}
