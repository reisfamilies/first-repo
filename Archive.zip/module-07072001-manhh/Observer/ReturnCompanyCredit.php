<?php





namespace Manh\Chu\Observer;

use Manh\Chu\Model\Credit\Order\Cancel as CancelOrder;
use Manh\Chu\Model\CustomerDataProvider;
use Manh\Chu\Model\Payment\ConfigProvider;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class ReturnCompanyCredit implements ObserverInterface
{
    /**
     * @var CustomerDataProvider
     */
    private $customerDataProvider;

    /**
     * @var CancelOrder
     */
    private $cancelOrder;

    public function __construct(
        CustomerDataProvider $customerDataProvider,
        CancelOrder $cancelOrder
    ) {
        $this->customerDataProvider = $customerDataProvider;
        $this->cancelOrder = $cancelOrder;
    }

    public function execute(Observer $observer)
    {
        $order = $observer->getData('order');
        if (empty($order)) {
            return;
        }
        try {
            $company = $this->customerDataProvider->getCompanyByCustomerId((int)$order->getCustomerId());
            if ($company
                && $company->getCompanyId()
                && $order->getPayment()->getMethod() == ConfigProvider::METHOD_NAME
            ) {
                $this->cancelOrder->execute($order);
            }
        } catch (NoSuchEntityException $e) {
            null;// Do nothing
        }
    }
}
