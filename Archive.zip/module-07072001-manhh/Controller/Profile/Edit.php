<?php





namespace Manh\Chu\Controller\Profile;

use Magento\Framework\App\ResponseInterface;

class Edit extends \Manh\Chu\Controller\AbstractAction
{
    public const RESOURCE = 'Manh_chu::edit_account';

    /**
     * @return ResponseInterface|\Magento\Framework\Controller\ResultInterface|\Magento\Framework\View\Result\Layout
     */
    public function execute()
    {
        $resultPage = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_PAGE);
        $resultPage->getConfig()->getTitle()->set(__('Edit Company Account'));

        return $resultPage;
    }
}
