<?php





namespace Manh\Chu\Controller\Profile;

class Create extends \Manh\Chu\Controller\AbstractAction
{
    public const RESOURCE = 'Manh_chu::edit_account';

    /**
     * @return \Magento\Framework\Controller\ResultInterface|\Magento\Framework\View\Result\Layout
     */
    public function execute()
    {
        $resultPage = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_PAGE);
        $resultPage->getConfig()->getTitle()->set(__('New Company Account'));

        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function isAllowed()
    {
        return $this->companyContext->isAllowedCustomerGroup()
            && !$this->companyContext->isCurrentUserCompanyUser();
    }
}
