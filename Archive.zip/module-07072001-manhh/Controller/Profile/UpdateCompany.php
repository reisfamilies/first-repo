<?php





namespace Manh\Chu\Controller\Profile;

class UpdateCompany extends SaveCompany
{
    public const RESOURCE = 'Manh_chu::edit_account';
    public const REDIRECT_URL = 'manh_company/profile/edit';

    /**
     * @var string
     */
    protected $redirectUrl = self::REDIRECT_URL;

    /**
     * @return bool
     */
    protected function isAllowed()
    {
        return $this->companyContext->isCurrentUserCompanyUser()
            && $this->companyContext->isResourceAllow(static::RESOURCE);
    }
}
