<?php





namespace Manh\Chu\Controller\Profile;

use Manh\Chu\Controller\AbstractAction;
use Manh\Chu\Model\Company\SaveCompanyData;
use Magento\Framework\App\ObjectManager;

class SaveCompany extends AbstractAction
{
    public const SESSION_NAME = 'Manh_CompanyAccount_Data';

    public const MANH_COMPANY_PROFILE_INDEX = 'manh_company/profile/index';

    public const REDIRECT_URL = 'manh_company/profile/create';

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    private $session;

    /**
     * @var string
     */
    protected $redirectUrl = self::REDIRECT_URL;

    /**
     * @var SaveCompanyData
     */
    private $saveCompanyData;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Manh\Chu\Model\CompanyContext $companyContext,
        \Psr\Log\LoggerInterface $logger,
        \Manh\Chu\Api\Data\CompanyInterfaceFactory $companyFactory,
        \Manh\Chu\Api\Data\CustomerInterfaceFactory $customerInterfaceFactory,
        \Manh\Chu\Api\CompanyRepositoryInterface $companyRepository,
        \Manh\Chu\Model\ResourceModel\Customer $customer,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\User\Model\ResourceModel\User\CollectionFactory $userCollectionFactory, // @deprecated
        \Manh\Chu\Model\ConfigProvider $configProvider,
        \Magento\Framework\Session\SessionManagerInterface $session,
        SaveCompanyData $saveCompanyData = null // TODO move to not optional
    ) {
        parent::__construct($context, $companyContext, $logger);
        $this->session = $session;
        $this->saveCompanyData = $saveCompanyData ?? ObjectManager::getInstance()->get(SaveCompanyData::class);
    }

    /**
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getParam('company', []);
        if ($data) {
            $this->saveCompany($data);
        }

        return $this->resultRedirectFactory->create()->setPath($this->redirectUrl);
    }

    /**
     * @param array $data
     */
    protected function saveCompany(array $data)
    {
        $this->session->setData(self::SESSION_NAME, $data);
        try {
            $this->saveCompanyData->saveCompany($data);
            $this->messageManager->addSuccessMessage($this->saveCompanyData->getSuccessMessage($data));
            $this->redirectUrl = self::MANH_COMPANY_PROFILE_INDEX;
            $this->session->setData(self::SESSION_NAME, []);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(
                __('An error occurred on the server. Your changes have not been saved.')
            );
            $this->logger->critical($e);
        }
    }

    /**
     * @return bool
     */
    protected function isAllowed()
    {
        return !$this->companyContext->isCurrentUserCompanyUser() && $this->companyContext->isAllowedCustomerGroup();
    }
}
