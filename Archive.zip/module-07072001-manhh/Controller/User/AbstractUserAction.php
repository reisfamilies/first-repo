<?php





namespace Manh\Chu\Controller\User;

use Magento\Customer\Api\CustomerRepositoryInterface;

abstract class AbstractUserAction extends \Manh\Chu\Controller\AbstractAction
{
    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Manh\Chu\Model\CompanyContext $companyContext,
        \Psr\Log\LoggerInterface $logger,
        CustomerRepositoryInterface $customerRepository
    ) {
        parent::__construct($context, $companyContext, $logger);
        $this->customerRepository = $customerRepository;
    }

    /**
     * @return bool
     */
    protected function isAllowed()
    {
        try {
            $customer = $this->customerRepository->getById($this->getRequest()->getParam('entity_id'));
            $isValidCustomer = $this->companyContext->isCurrentCompanyUser($customer);
        } catch (\Exception $e) {
            $this->logger->error($e->getMessage());
            $isValidCustomer = false;
        }

        return $isValidCustomer && parent::isAllowed();
    }
}
