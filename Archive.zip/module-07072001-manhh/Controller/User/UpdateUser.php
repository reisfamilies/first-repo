<?php





namespace Manh\Chu\Controller\User;

class UpdateUser extends SaveUser
{
    public const RESOURCE = 'Manh_chu::users_edit';
}
