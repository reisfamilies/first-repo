<?php





namespace Manh\Chu\Controller\Role;

class UpdateRole extends SaveRole
{
    public const RESOURCE = 'Manh_chu::roles_edit';
}
