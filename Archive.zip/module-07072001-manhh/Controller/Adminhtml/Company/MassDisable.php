<?php





namespace Manh\Chu\Controller\Adminhtml\Company;

use Magento\Framework\Data\Collection\AbstractDb;
use Manh\Chu\Model\Source\Company\Status;

class MassDisable extends \Manh\Chu\Controller\Adminhtml\Company\MassActionAbstract
{
    /**
     * @param AbstractDb $collection
     */
    public function doAction(AbstractDb $collection)
    {
        $collectionSize = $collection->getSize();
        foreach ($collection as $company) {
            /**
             * @TODO be shure, that all customer of company will be blocked
             */
            $company->setStatus(Status::STATUS_INACTIVE);
            $this->companyRepository->save($company);
        }
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deactivated.', $collectionSize));
    }
}
