<?php





namespace Manh\Chu\Block\Credit;

use Magento\Framework\View\Element\Template;

class Credit extends Template
{

}
