<?php


namespace Manh\Chu\Block\Account;

class Delimiter extends \Magento\Customer\Block\Account\Delimiter
{
    private const LINKS_RESOURCES = [
        'Manh_chu::view_account',
        'Manh_chu::users_view',
        'Manh_chu::roles_view',
        'Manh_chu::orders_all_view',
        'Manh_chu::use_credit'
    ];

    /**
     * @return string
     */
    protected function _toHtml()
    {
        /** @var \Manh\Chu\Model\CompanyContext $context */
        $context = $this->getData('companyContext');
        $html = '';
        if ($context->isCreateCompanyAllowed()
            || ($context->isCurrentUserCompanyUser() && $this->isLinkResourceAllowed())
        ) {
            $html = parent::_toHtml();
        }

        return $html;
    }

    /**
     * Determine is some of company links allowed by ACL
     *
     * @return bool
     */
    private function isLinkResourceAllowed(): bool
    {
        $allowed = false;

        /** @var \Manh\Chu\Model\CompanyContext $context */
        $context = $this->getData('companyContext');

        foreach ($this->getResourceArray() as $linkResource) {
            if ($allowed = $context->isResourceAllow($linkResource)) {
                break;
            }
        }

        return $allowed;
    }

    public function getResourceArray(): array
    {
        return self::LINKS_RESOURCES;
    }
}
