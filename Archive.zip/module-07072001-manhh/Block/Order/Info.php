<?php





namespace Manh\Chu\Block\Order;

class Info extends \Magento\Sales\Block\Order\Info
{
    public function getCustomerName(): string
    {
        return $this->getOrderInfo()->getCustomerName($this->getOrder());
    }

    private function getOrderInfo(): \Manh\Chu\ViewModel\Order
    {
        return $this->getData('orderInfo');
    }
}
