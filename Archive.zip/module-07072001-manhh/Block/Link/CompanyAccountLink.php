<?php





namespace Manh\Chu\Block\Link;

class CompanyAccountLink extends AbstractLink
{
    /**
     * @return bool
     */
    protected function isAllowed()
    {
        return $this->companyContext->isCreateCompanyAllowed()
            || ($this->companyContext->isCurrentUserCompanyUser() && parent::isAllowed());
    }
}
