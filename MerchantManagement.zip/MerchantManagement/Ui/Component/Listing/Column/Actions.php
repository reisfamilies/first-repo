<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Ui\Component\Listing\Column;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class Actions
 * @package Tigren\MerchantManagement\Ui\Component\Listing\Column
 */
class Actions extends Column
{
    /**
     * Url path
     */
    public const URL_PATH_EDIT = 'merchant/merchant/edit';

    public const URL_PATH_SYNC = 'merchant/merchant/sync';

    /**
     * @var UrlInterface
     */
    protected UrlInterface $urlBuilder;

    /**
     * Actions Constructor.
     *
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @inheritDoc
     */
    public function prepareDataSource(array $dataSource): array
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['merchant_id'])) {
                    $item[$this->getData('name')] = [
                        'edit' => [
                            'href' => $this->urlBuilder->getUrl(
                                static::URL_PATH_EDIT,
                                [
                                    'merchant_id' => $item['merchant_id']
                                ]
                            ),
                            'label' => __('Edit')
                        ],
                        'sync' => [
                            'href' => $this->urlBuilder->getUrl(
                                static::URL_PATH_SYNC,
                                [
                                    'merchant_id' => $item['merchant_id']
                                ]
                            ),
                            'label' => __('Sync from Munero')
                        ]
                    ];
                }
            }
        }

        return $dataSource;
    }
}
