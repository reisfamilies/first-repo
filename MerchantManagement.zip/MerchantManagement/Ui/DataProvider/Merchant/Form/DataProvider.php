<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Ui\DataProvider\Merchant\Form;

use Magento\Framework\Exception\LocalizedException;
use Tigren\MerchantManagement\Api\MerchantRepositoryInterface;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;
use Tigren\MerchantManagement\Model\RegistryConstants;
use Tigren\MerchantManagement\Model\ResourceModel\Merchant\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Tigren\MerchantManagement\Model\ResourceModel\ProductPrice\Grid\CollectionFactory as ProductPriceGridCollectionFactory;


/**
 * Class DataProvider
 * @package Tigren\MerchantManagement\Ui\DataProvider\Merchant\Form
 */
class DataProvider extends AbstractDataProvider
{
    /**
     * @var CollectionFactory
     */
    private CollectionFactory $collectionFactory;

    /**
     * @var DataPersistorInterface
     */
    private DataPersistorInterface $dataPersistor;

    /**
     * @var MerchantRepositoryInterface
     */
    private MerchantRepositoryInterface $merchantRepository;


    /**
     * @var ProductPriceGridCollectionFactory
     */
    private $productPriceGridCollectionFactory;

    public function __construct(
        CollectionFactory $collectionFactory,
        $name,
        $primaryFieldName,
        $requestFieldName,
        DataPersistorInterface $dataPersistor,
        MerchantRepositoryInterface $merchantRepository,
        ProductPriceGridCollectionFactory $productPriceGridCollectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->collection = $this->collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->merchantRepository = $merchantRepository;
        $this->productPriceGridCollectionFactory = $productPriceGridCollectionFactory;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @return array
     * @throws LocalizedException
     */
    public function getData(): array
    {
        $data = parent::getData();
        if (($data['totalRecords'] > 0) && isset($data['items'][0][MerchantInterface::MERCHANT_ID])) {
            $merchantId = (int)$data['items'][0][MerchantInterface::MERCHANT_ID];
            $merchant = $this->merchantRepository->getById($merchantId);
            $data = [$merchantId => ['merchant_information' => $merchant->getData()]];
            $data[$merchantId]['products']['merchant_product_ids'] = $this->getProductData($merchantId);

            if (!empty($merchant?->getLogo())) {
                $imageLogo[] = [
                    'name' => $merchant->getMerchantName() ?? '',
                    'url' => $merchant->getLogo(),
                    'size' => $this->getImageSizeFromUrl($merchant->getLogo()) ?? 0,
                ];

                $data[$merchantId]['merchant_information']['logo'] = $imageLogo;
            }

            if (!empty($merchant?->getLogoThumbnail())) {
                $imageLogoThumbnail[] = [
                    'name' => $merchant->getMerchantName() ?? '',
                    'url' => $merchant->getLogoThumbnail(),
                    'size' => $this->getImageSizeFromUrl($merchant->getLogoThumbnail()) ?? 0,
                ];

                $data[$merchantId]['merchant_information']['logo_thumbnail'] = $imageLogoThumbnail;
            }
        }

        if ($savedData = $this->dataPersistor->get(RegistryConstants::MERCHANT_DATA)) {
            $savedMerchantId = $savedData[MerchantInterface::MERCHANT_ID] ?? null;
            if (isset($data[$savedMerchantId])) {
                $data[$savedMerchantId] = array_merge($data[$savedMerchantId], $savedData);
            } else {
                $data[$savedMerchantId] = $savedData;
            }
            $this->dataPersistor->clear(RegistryConstants::MERCHANT_DATA);
        }

        return $data;
    }

    /**
     * @param $url
     * @return false|int
     */
    public function getImageSizeFromUrl($url): false|int
    {
        try {
            $headers = get_headers($url, 1);

            if ($headers && isset($headers["Content-Length"])) {
                return (int) $headers["Content-Length"];
            }
        } catch (\Exception) {

        }

        return false;
    }

    private function getProductData($merchantId)
    {
        $productPriceCollection = $this->productPriceGridCollectionFactory->create();
        $productPriceCollection->addNameAttributeToSelect()->addMerchantIdFilter($merchantId);
        $result = [[
            'entity_id' => '1',
            'sku' => '2',
            'name' => '3',
        ]];

        foreach ($productPriceCollection->getItems() as $productPrice) {
            $result[] = $this->fillData($productPrice);
        }

        return ['merchant_product_container' => $result];
    }

    /**
     * @param $product
     *
     * @return array
     */
    private function fillData($productPrice)
    {
        return [
            'entity_id' => $productPrice->getE(),
            'sku' => $productPrice->getSku(),
            'name' => $productPrice->getName(),
        ];
    }
}
