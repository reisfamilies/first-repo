<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Cron;

use Tigren\MerchantManagement\Model\MerchantResource;

/**
 * Class SyncMerchants
 * @package Tigren\MerchantManagement\Cron
 */
class SyncMerchants
{
    /**
     * @var MerchantResource
     */
    private MerchantResource $merchantResource;

    /**
     * SyncMerchants Constructor.
     *
     * @param MerchantResource $merchantResource
     */
    public function __construct(
        MerchantResource $merchantResource
    )
    {
        $this->merchantResource = $merchantResource;
    }

    public function execute(): void
    {
        $this->merchantResource->syncMerchants();
    }
}
