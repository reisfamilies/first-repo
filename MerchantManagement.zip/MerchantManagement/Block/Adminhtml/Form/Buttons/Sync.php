<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Block\Adminhtml\Form\Buttons;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * Class Sync
 * @package Tigren\MerchantManagement\Block\Adminhtml\Form\Buttons
 */
class Sync implements ButtonProviderInterface
{
    public const ID = 'merchant_id';

    /**
     * @var UrlInterface
     */
    private UrlInterface $urlBuilder;

    /**
     * @var RequestInterface
     */
    private RequestInterface $request;

    /**
     * Delete Constructor.
     *
     * @param UrlInterface $urlBuilder
     * @param RequestInterface $request
     */
    public function __construct(
        UrlInterface $urlBuilder,
        RequestInterface $request
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->request = $request;
    }

    public function getButtonData(): array
    {
        return [
            'label' => __('Sync from Munero'),
            'class' => 'delete',
            'on_click' => 'deleteConfirm(\'' . __(
                    'Are you sure you want to do this?'
                ) . '\', \'' . $this->getSyncUrl() . '\', {"data": {}})',
            'sort_order' => 10
        ];
    }

    private function getSyncUrl(): string
    {
        return $this->urlBuilder->getUrl(
            '*/*/sync',
            [self::ID => $this->request->getParam(self::ID)]
        );
    }
}
