<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Controller\Adminhtml\Merchant;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\ForwardFactory;
use Magento\Backend\Model\View\Result\Page;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Tigren\MerchantManagement\Model\Backend\Merchant\Registry as MerchantRegistry;
use Tigren\MerchantManagement\Model\Repository\MerchantRepository;

/**
 * Class AbstractMerchant
 * @package Tigren\MerchantManagement\Controller\Adminhtml\Merchant
 */
abstract class AbstractMerchant extends Action
{
    public const ADMIN_RESOURCE = 'Tigren_MerchantManagement::merchant_management';

    /**
     * @var ForwardFactory
     */
    protected ForwardFactory $resultForwardFactory;

    /**
     * @var RedirectFactory
     */
    protected $resultRedirectFactory;

    /**
     * @var MerchantRegistry
     */
    private MerchantRegistry $merchantRegistry;

    /**
     * @var MerchantRepository
     */
    protected MerchantRepository $merchantRepository;

    /**
     * AbstractMerchant Constructor.
     *
     * @param Context $context
     * @param ForwardFactory $resultForwardFactory
     * @param RedirectFactory $resultRedirectFactory
     * @param MerchantRepository $merchantRepository
     * @param MerchantRegistry $merchantRegistry
     */
    public function __construct(
        Context $context,
        ForwardFactory $resultForwardFactory,
        RedirectFactory $resultRedirectFactory,
        MerchantRepository $merchantRepository,
        MerchantRegistry $merchantRegistry
    ) {
        parent::__construct($context);
        $this->resultForwardFactory = $resultForwardFactory;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->merchantRegistry = $merchantRegistry;
        $this->merchantRepository = $merchantRepository;
    }

    public function getMerchantRegistry(): MerchantRegistry
    {
        return $this->merchantRegistry;
    }

    /**
     * @param Page $resultPage
     * @return Page
     */
    protected function initPage($resultPage)
    {
        $resultPage->setActiveMenu('Tigren_MerchantManagement::merchants');
        $resultPage->getConfig()->getTitle()->prepend(__('Merchants'));

        return $resultPage;
    }
}
