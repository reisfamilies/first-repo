<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Controller\Adminhtml\Merchant;

use Exception;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\ForwardFactory;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;
use Tigren\MerchantManagement\Model\Backend\Merchant\Registry as MerchantRegistry;
use Tigren\MerchantManagement\Model\MerchantResource;
use Tigren\MerchantManagement\Model\Repository\MerchantRepository;

/**
 * Class Sync
 * @package Tigren\MerchantManagement\Controller\Adminhtml\Merchant
 */
class Sync extends AbstractMerchant
{
    /**
     * @var MerchantResource
     */
    private MerchantResource $merchantResource;

    /**
     * Sync Constructor.
     *
     * @param Context $context
     * @param ForwardFactory $resultForwardFactory
     * @param RedirectFactory $resultRedirectFactory
     * @param MerchantRepository $merchantRepository
     * @param MerchantRegistry $merchantRegistry
     * @param MerchantResource $merchantResource
     */
    public function __construct(
        Context $context,
        ForwardFactory $resultForwardFactory,
        RedirectFactory $resultRedirectFactory,
        MerchantRepository $merchantRepository,
        MerchantRegistry $merchantRegistry,
        MerchantResource $merchantResource
    ) {
        parent::__construct($context, $resultForwardFactory, $resultRedirectFactory, $merchantRepository,
            $merchantRegistry);
        $this->merchantResource = $merchantResource;
    }

    /**
     * {@inheritdoc}
     */
    public function execute(): Redirect|ResultInterface|ResponseInterface
    {
        $merchantId = $this->getRequest()->getParam(MerchantInterface::MERCHANT_ID);
        if (!$merchantId) {
            $this->messageManager->addErrorMessage(__('We can\'t find merchant to sync.'));
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }

        try {
            $merchant = $this->merchantRepository->getById($merchantId);
            if ($merchant == null) {
                $this->messageManager->addErrorMessage(__('We can\'t find merchant to sync.'));
                return $this->resultRedirectFactory->create()->setPath('*/*/');

            }

            $queryParams = [
                'search' => $merchant->getMerchantCode()
            ];
            $isSuccess = $this->merchantResource->syncMerchants($queryParams);
            if ($isSuccess) {
                $this->messageManager->addSuccessMessage(__('Merchant was successfully synced'));
            } else {
                $this->messageManager->addErrorMessage(__('An issue occurred while processing Munero data. Please refer to the log files for detailed information.'));
            }
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }

        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }
}
