<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Controller\Adminhtml\Merchant;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;

/**
 * Class Edit
 * @package Tigren\MerchantManagement\Controller\Adminhtml\Merchant
 */
class Edit extends AbstractMerchant
{
    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $merchantId = (int)$this->getRequest()->getParam(MerchantInterface::MERCHANT_ID);

        try {
            /**
             * @var MerchantInterface $model
             */
            if ($merchantId) {
                $model = $this->merchantRepository->getById($merchantId);
            } else {
                $model = $this->merchantRepository->getEmptyModel();
            }
            $this->getMerchantRegistry()->set($model);
        } catch (NoSuchEntityException $exception) {
            $resultRedirect = $this->resultRedirectFactory->create();
            $this->messageManager->addErrorMessage(__('This merchant no longer exists.'));

            return $resultRedirect->setPath('*/*/');
        }

        $merchantName = $model->getMerchantName() ?? '';
        $text = $merchantName ? __('View Merchant "%1"', $merchantName) : '';
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $this->initPage($resultPage)->getConfig()->getTitle()->prepend($text);

        return $resultPage;
    }
}
