<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Controller\Adminhtml\Merchant;

use Exception;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\ForwardFactory;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Psr\Log\LoggerInterface;
use Tigren\MerchantManagement\Model\Backend\Merchant\Registry as MerchantRegistry;
use Tigren\MerchantManagement\Model\Repository\MerchantRepository;
use Tigren\MerchantManagement\Model\ScheduleManagement;

/**
 * Class SyncAll
 * @package Tigren\MerchantManagement\Controller\Adminhtml\Merchant
 */
class SyncAll extends AbstractMerchant
{
    /**
     * @var LoggerInterface
     */
    private LoggerInterface $logger;

    /**
     * @var ScheduleManagement
     */
    private ScheduleManagement $scheduleManagement;

    /**
     * SyncAll Constructor.
     *
     * @param Context $context
     * @param ForwardFactory $resultForwardFactory
     * @param RedirectFactory $resultRedirectFactory
     * @param MerchantRepository $merchantRepository
     * @param MerchantRegistry $merchantRegistry
     * @param LoggerInterface $logger
     * @param ScheduleManagement $scheduleManagement
     */
    public function __construct(
        Context $context,
        ForwardFactory $resultForwardFactory,
        RedirectFactory $resultRedirectFactory,
        MerchantRepository $merchantRepository,
        MerchantRegistry $merchantRegistry,
        LoggerInterface $logger,
        ScheduleManagement $scheduleManagement
    ) {
        parent::__construct($context, $resultForwardFactory, $resultRedirectFactory, $merchantRepository,
            $merchantRegistry);
        $this->logger = $logger;
        $this->scheduleManagement = $scheduleManagement;
    }

    /**
     * {@inheritdoc}
     */
    public function execute(): Redirect|ResultInterface|ResponseInterface
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            $this->scheduleManagement->scheduleNow('tigren_merchant_management_sync_merchant');
            $this->messageManager->addSuccessMessage(__('The cron job has been successfully added to the scheduler.'));
        } catch (Exception $exception) {
            $this->messageManager->addErrorMessage(__('An error occurred while adding the cron job to the scheduler. Please check the logs for more details.'));
            $this->logger->critical($exception);
        }

        return $resultRedirect->setPath('*/*/');
    }
}
