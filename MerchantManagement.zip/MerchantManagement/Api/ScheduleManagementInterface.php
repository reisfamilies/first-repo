<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Api;

use Magento\Cron\Model\Schedule;

/**
 * Class ScheduleManagementInterface
 * @package Tigren\MerchantManagement\Api
 */
interface ScheduleManagementInterface
{
    public const TIME_FORMAT = 'Y-m-d H:i:00';

    /**
     * @param string $jobCode
     * @return Schedule
     */
    public function scheduleNow(string $jobCode): Schedule;
}
