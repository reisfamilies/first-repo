<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchResultsInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;

/**
 * Class MerchantRepositoryInterface
 * @package Tigren\MerchantManagement\Api
 */
interface MerchantRepositoryInterface
{
    /**
     * Save merchant.
     *
     * @param MerchantInterface $merchant
     * @return MerchantInterface
     * @throws LocalizedException
     */
    public function save(MerchantInterface $merchant);

    /**
     * Retrieve merchant.
     *
     * @param int $merchantId
     * @return MerchantInterface
     * @throws LocalizedException
     */
    public function getById($merchantId);

    /**
     * Retrieve merchant by user id.
     *
     * @param string $merchantCode
     *
     * @return MerchantInterface
     * @throws LocalizedException
     */
    public function getByMerchantCode($merchantCode);

    /**
     * Retrieve merchants matching the specified criteria.
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return SearchResultsInterface
     * @throws LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * Delete merchant.
     *
     * @param MerchantInterface $merchant
     * @return bool true on success
     * @throws LocalizedException
     */
    public function delete(MerchantInterface $merchant);

    /**
     * Delete merchant by ID.
     *
     * @param int $merchantId
     * @return bool true on success
     * @throws NoSuchEntityException
     * @throws LocalizedException
     */
    public function deleteById($merchantId);


    /**
     * Get empty model of merchant
     *
     * @return MerchantInterface
     */
    public function getEmptyModel();
}
