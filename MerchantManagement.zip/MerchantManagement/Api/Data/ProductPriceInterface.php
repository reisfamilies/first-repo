<?php

namespace Tigren\MerchantManagement\Api\Data;

interface ProductPriceInterface
{
    /**
     * String constants for property names
     */
    public const TABLE_NAME = 'tigren_merchant_product_price';
    public const ENTITY_ID = "entity_id";
    public const MERCHANT_ID = "merchant_id";
    public const PRODUCT_ID = "product_id";
    public const DENOMINATIONS = "denominations";
    public const NRP = "nrp";
    public const VAT = "vat";
    public const RRP = "rrp";
    public const DISCOUNT = "discount";
    public const OTHER_FEES = "other_fees";

    /**
     * Getter for EntityId.
     *
     * @return int|null
     */
    public function getEntityId(): ?int;

    /**
     * Setter for EntityId.
     *
     * @param int|null $entityId
     *
     * @return void
     */
    public function setEntityId(?int $entityId): void;

    /**
     * Getter for MerchantId.
     *
     * @return int|null
     */
    public function getMerchantId(): ?int;

    /**
     * Setter for MerchantId.
     *
     * @param int|null $merchantId
     *
     * @return void
     */
    public function setMerchantId(?int $merchantId): void;

    /**
     * Getter for ProductId.
     *
     * @return int|null
     */
    public function getProductId(): ?int;

    /**
     * Setter for ProductId.
     *
     * @param int|null $productId
     *
     * @return void
     */
    public function setProductId(?int $productId): void;

    /**
     * Getter for Denominations.
     *
     * @return string|null
     */
    public function getDenominations(): ?string;

    /**
     * Setter for Denominations.
     *
     * @param string|null $denominations
     *
     * @return void
     */
    public function setDenominations(?string $denominations): void;

    /**
     * Getter for Nrp.
     *
     * @return float|null
     */
    public function getNrp(): ?float;

    /**
     * Setter for Nrp.
     *
     * @param float|null $nrp
     *
     * @return void
     */
    public function setNrp(?float $nrp): void;

    /**
     * Getter for Vat.
     *
     * @return float|null
     */
    public function getVat(): ?float;

    /**
     * Setter for Vat.
     *
     * @param float|null $vat
     *
     * @return void
     */
    public function setVat(?float $vat): void;

    /**
     * Getter for Rrp.
     *
     * @return float|null
     */
    public function getRrp(): ?float;

    /**
     * Setter for Rrp.
     *
     * @param float|null $rrp
     *
     * @return void
     */
    public function setRrp(?float $rrp): void;

    /**
     * Getter for Discount.
     *
     * @return float|null
     */
    public function getDiscount(): ?float;

    /**
     * Setter for Discount.
     *
     * @param float|null $discount
     *
     * @return void
     */
    public function setDiscount(?float $discount): void;

    /**
     * Getter for OtherFees.
     *
     * @return float|null
     */
    public function getOtherFees(): ?float;

    /**
     * Setter for OtherFees.
     *
     * @param float|null $otherFees
     *
     * @return void
     */
    public function setOtherFees(?float $otherFees): void;
}
