<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Api\Data;

/**
 * Class MerchantInterface
 * @package Tigren\MerchantManagement\Api\Data
 */
interface MerchantInterface
{
    /**
     * String constants for property names
     */
    public const TABLE_NAME = "tigren_merchant";
    public const MERCHANT_ID = "merchant_id";
    public const MERCHANT_CODE = "merchant_code";
    public const MERCHANT_NAME = "merchant_name";
    public const CONTACT_PERSON_NAME = "contact_person_name";
    public const EMAIL_ADDRESS = "email_address";
    public const WEBSITE = "website";
    public const LOGO = "logo";
    public const LOGO_THUMBNAIL = "logo_thumbnail";
    public const PHONE_NUMBER = "phone_number";
    public const ADDRESS = "address";
    public const MOBILE_NUMBER = "mobile_number";
    public const BRIEF_DESCRIPTION = "brief_description";

    /**
     * Getter for MerchantId.
     *
     * @return int
     */
    public function getMerchantId(): int;

    /**
     * Setter for MerchantId.
     *
     * @param int $merchantId
     *
     * @return void
     */
    public function setMerchantId(int $merchantId): void;

    /**
     * Getter for MerchantCode.
     *
     * @return string|null
     */
    public function getMerchantCode(): ?string;

    /**
     * Setter for MerchantCode.
     *
     * @param string|null $merchantCode
     *
     * @return void
     */
    public function setMerchantCode(?string $merchantCode): void;

    /**
     * Getter for MerchantName.
     *
     * @return string|null
     */
    public function getMerchantName(): ?string;

    /**
     * Setter for MerchantName.
     *
     * @param string|null $merchantName
     *
     * @return void
     */
    public function setMerchantName(?string $merchantName): void;

    /**
     * Getter for ContactPersonName.
     *
     * @return string|null
     */
    public function getContactPersonName(): ?string;

    /**
     * Setter for ContactPersonName.
     *
     * @param string|null $contactPersonName
     *
     * @return void
     */
    public function setContactPersonName(?string $contactPersonName): void;

    /**
     * Getter for EmailAddress.
     *
     * @return string|null
     */
    public function getEmailAddress(): ?string;

    /**
     * Setter for EmailAddress.
     *
     * @param string|null $emailAddress
     *
     * @return void
     */
    public function setEmailAddress(?string $emailAddress): void;

    /**
     * Getter for Website.
     *
     * @return string|null
     */
    public function getWebsite(): ?string;

    /**
     * Setter for Website.
     *
     * @param string|null $website
     *
     * @return void
     */
    public function setWebsite(?string $website): void;

    /**
     * Getter for Logo.
     *
     * @return string|null
     */
    public function getLogo(): ?string;

    /**
     * Setter for Logo.
     *
     * @param string|null $logo
     *
     * @return void
     */
    public function setLogo(?string $logo): void;

    /**
     * Getter for LogoThumbnail.
     *
     * @return string|null
     */
    public function getLogoThumbnail(): ?string;

    /**
     * Setter for LogoThumbnail.
     *
     * @param string|null $logoThumbnail
     *
     * @return void
     */
    public function setLogoThumbnail(?string $logoThumbnail): void;

    /**
     * Getter for PhoneNumber.
     *
     * @return string|null
     */
    public function getPhoneNumber(): ?string;

    /**
     * Setter for PhoneNumber.
     *
     * @param string|null $phoneNumber
     *
     * @return void
     */
    public function setPhoneNumber(?string $phoneNumber): void;

    /**
     * Getter for Address.
     *
     * @return string|null
     */
    public function getAddress(): ?string;

    /**
     * Setter for Address.
     *
     * @param string|null $address
     *
     * @return void
     */
    public function setAddress(?string $address): void;

    /**
     * Getter for MobileNumber.
     *
     * @return string|null
     */
    public function getMobileNumber(): ?string;

    /**
     * Setter for MobileNumber.
     *
     * @param string|null $mobileNumber
     *
     * @return void
     */
    public function setMobileNumber(?string $mobileNumber): void;

    /**
     * Getter for BriefDescription.
     *
     * @return string|null
     */
    public function getBriefDescription(): ?string;

    /**
     * Setter for BriefDescription.
     *
     * @param string|null $briefDescription
     *
     * @return void
     */
    public function setBriefDescription(?string $briefDescription): void;
}
