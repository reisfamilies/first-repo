<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Api;

use Magento\Cron\Model\Schedule;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class ScheduleRepositoryInterface
 * @package Tigren\MerchantManagement\Api
 */
interface ScheduleRepositoryInterface
{
    /**
     * @param Schedule $schedule
     * @return Schedule
     * @throws CouldNotSaveException
     */
    public function save(Schedule $schedule): Schedule;
}
