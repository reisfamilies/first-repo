<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model;

use Magento\Framework\Model\AbstractModel;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;
use Tigren\MerchantManagement\Model\ResourceModel\Merchant as ResourceModel;

/**
 * Class Merchant
 * @package Tigren\MerchantManagement\Model
 */
class Merchant extends AbstractModel implements MerchantInterface
{
    /**
     * @var string
     */
    protected $_eventPrefix = 'tigren_merchant_model';

    /**
     * Initialize magento model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * Getter for MerchantId.
     *
     * @return int
     */
    public function getMerchantId(): int
    {
        return (int)$this->getData(self::MERCHANT_ID);
    }

    /**
     * Setter for MerchantId.
     *
     * @param int $merchantId
     *
     * @return void
     */
    public function setMerchantId(int $merchantId): void
    {
        $this->setData(self::MERCHANT_ID, $merchantId);
    }

    /**
     * Getter for MerchantCode.
     *
     * @return string|null
     */
    public function getMerchantCode(): ?string
    {
        return $this->getData(self::MERCHANT_CODE);
    }

    /**
     * Setter for MerchantCode.
     *
     * @param string|null $merchantCode
     *
     * @return void
     */
    public function setMerchantCode(?string $merchantCode): void
    {
        $this->setData(self::MERCHANT_CODE, $merchantCode);
    }

    /**
     * Getter for MerchantName.
     *
     * @return string|null
     */
    public function getMerchantName(): ?string
    {
        return $this->getData(self::MERCHANT_NAME);
    }

    /**
     * Setter for MerchantName.
     *
     * @param string|null $merchantName
     *
     * @return void
     */
    public function setMerchantName(?string $merchantName): void
    {
        $this->setData(self::MERCHANT_NAME, $merchantName);
    }

    /**
     * Getter for ContactPersonName.
     *
     * @return string|null
     */
    public function getContactPersonName(): ?string
    {
        return $this->getData(self::CONTACT_PERSON_NAME);
    }

    /**
     * Setter for ContactPersonName.
     *
     * @param string|null $contactPersonName
     *
     * @return void
     */
    public function setContactPersonName(?string $contactPersonName): void
    {
        $this->setData(self::CONTACT_PERSON_NAME, $contactPersonName);
    }

    /**
     * Getter for EmailAddress.
     *
     * @return string|null
     */
    public function getEmailAddress(): ?string
    {
        return $this->getData(self::EMAIL_ADDRESS);
    }

    /**
     * Setter for EmailAddress.
     *
     * @param string|null $emailAddress
     *
     * @return void
     */
    public function setEmailAddress(?string $emailAddress): void
    {
        $this->setData(self::EMAIL_ADDRESS, $emailAddress);
    }

    /**
     * Getter for Website.
     *
     * @return string|null
     */
    public function getWebsite(): ?string
    {
        return $this->getData(self::WEBSITE);
    }

    /**
     * Setter for Website.
     *
     * @param string|null $website
     *
     * @return void
     */
    public function setWebsite(?string $website): void
    {
        $this->setData(self::WEBSITE, $website);
    }

    /**
     * Getter for Logo.
     *
     * @return string|null
     */
    public function getLogo(): ?string
    {
        return $this->getData(self::LOGO);
    }

    /**
     * Setter for Logo.
     *
     * @param string|null $logo
     *
     * @return void
     */
    public function setLogo(?string $logo): void
    {
        $this->setData(self::LOGO, $logo);
    }

    /**
     * Getter for LogoThumbnail.
     *
     * @return string|null
     */
    public function getLogoThumbnail(): ?string
    {
        return $this->getData(self::LOGO_THUMBNAIL);
    }

    /**
     * Setter for LogoThumbnail.
     *
     * @param string|null $logoThumbnail
     *
     * @return void
     */
    public function setLogoThumbnail(?string $logoThumbnail): void
    {
        $this->setData(self::LOGO_THUMBNAIL, $logoThumbnail);
    }

    /**
     * Getter for PhoneNumber.
     *
     * @return string|null
     */
    public function getPhoneNumber(): ?string
    {
        return $this->getData(self::PHONE_NUMBER);
    }

    /**
     * Setter for PhoneNumber.
     *
     * @param string|null $phoneNumber
     *
     * @return void
     */
    public function setPhoneNumber(?string $phoneNumber): void
    {
        $this->setData(self::PHONE_NUMBER, $phoneNumber);
    }

    /**
     * Getter for Address.
     *
     * @return string|null
     */
    public function getAddress(): ?string
    {
        return $this->getData(self::ADDRESS);
    }

    /**
     * Setter for Address.
     *
     * @param string|null $address
     *
     * @return void
     */
    public function setAddress(?string $address): void
    {
        $this->setData(self::ADDRESS, $address);
    }

    /**
     * Getter for MobileNumber.
     *
     * @return string|null
     */
    public function getMobileNumber(): ?string
    {
        return $this->getData(self::MOBILE_NUMBER);
    }

    /**
     * Setter for MobileNumber.
     *
     * @param string|null $mobileNumber
     *
     * @return void
     */
    public function setMobileNumber(?string $mobileNumber): void
    {
        $this->setData(self::MOBILE_NUMBER, $mobileNumber);
    }

    /**
     * Getter for BriefDescription.
     *
     * @return string|null
     */
    public function getBriefDescription(): ?string
    {
        return $this->getData(self::BRIEF_DESCRIPTION);
    }

    /**
     * Setter for BriefDescription.
     *
     * @param string|null $briefDescription
     *
     * @return void
     */
    public function setBriefDescription(?string $briefDescription): void
    {
        $this->setData(self::BRIEF_DESCRIPTION, $briefDescription);
    }
}
