<?php

namespace Tigren\MerchantManagement\Model;

use Magento\Framework\Model\AbstractExtensibleModel;
use Tigren\MerchantManagement\Api\Data\ProductPriceInterface;
use Tigren\MerchantManagement\Model\ResourceModel;

class ProductPrice extends AbstractExtensibleModel implements ProductPriceInterface
{
    public function _construct()
    {
        parent::_construct();
        $this->_init(ResourceModel\ProductPrice::class);
    }

    /**
     * Getter for EntityId.
     *
     * @return int|null
     */
    public function getEntityId(): ?int
    {
        return $this->getData(self::ENTITY_ID) === null ? null
            : (int)$this->getData(self::ENTITY_ID);
    }

    /**
     * Setter for EntityId.
     *
     * @param int|null $entityId
     *
     * @return void
     */
    public function setEntityId(?int $entityId): void
    {
        $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * Getter for MerchantId.
     *
     * @return int|null
     */
    public function getMerchantId(): ?int
    {
        return $this->getData(self::MERCHANT_ID) === null ? null
            : (int)$this->getData(self::MERCHANT_ID);
    }

    /**
     * Setter for MerchantId.
     *
     * @param int|null $merchantId
     *
     * @return void
     */
    public function setMerchantId(?int $merchantId): void
    {
        $this->setData(self::MERCHANT_ID, $merchantId);
    }

    /**
     * Getter for ProductId.
     *
     * @return int|null
     */
    public function getProductId(): ?int
    {
        return $this->getData(self::PRODUCT_ID) === null ? null
            : (int)$this->getData(self::PRODUCT_ID);
    }

    /**
     * Setter for ProductId.
     *
     * @param int|null $productId
     *
     * @return void
     */
    public function setProductId(?int $productId): void
    {
        $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * Getter for Denominations.
     *
     * @return string|null
     */
    public function getDenominations(): ?string
    {
        return $this->getData(self::DENOMINATIONS);
    }

    /**
     * Setter for Denominations.
     *
     * @param string|null $denominations
     *
     * @return void
     */
    public function setDenominations(?string $denominations): void
    {
        $this->setData(self::DENOMINATIONS, $denominations);
    }

    /**
     * Getter for Nrp.
     *
     * @return float|null
     */
    public function getNrp(): ?float
    {
        return $this->getData(self::NRP) === null ? null
            : (float)$this->getData(self::NRP);
    }

    /**
     * Setter for Nrp.
     *
     * @param float|null $nrp
     *
     * @return void
     */
    public function setNrp(?float $nrp): void
    {
        $this->setData(self::NRP, $nrp);
    }

    /**
     * Getter for Vat.
     *
     * @return float|null
     */
    public function getVat(): ?float
    {
        return $this->getData(self::VAT) === null ? null
            : (float)$this->getData(self::VAT);
    }

    /**
     * Setter for Vat.
     *
     * @param float|null $vat
     *
     * @return void
     */
    public function setVat(?float $vat): void
    {
        $this->setData(self::VAT, $vat);
    }

    /**
     * Getter for Rrp.
     *
     * @return float|null
     */
    public function getRrp(): ?float
    {
        return $this->getData(self::RRP) === null ? null
            : (float)$this->getData(self::RRP);
    }

    /**
     * Setter for Rrp.
     *
     * @param float|null $rrp
     *
     * @return void
     */
    public function setRrp(?float $rrp): void
    {
        $this->setData(self::RRP, $rrp);
    }

    /**
     * Getter for Discount.
     *
     * @return float|null
     */
    public function getDiscount(): ?float
    {
        return $this->getData(self::DISCOUNT) === null ? null
            : (float)$this->getData(self::DISCOUNT);
    }

    /**
     * Setter for Discount.
     *
     * @param float|null $discount
     *
     * @return void
     */
    public function setDiscount(?float $discount): void
    {
        $this->setData(self::DISCOUNT, $discount);
    }

    /**
     * Getter for OtherFees.
     *
     * @return float|null
     */
    public function getOtherFees(): ?float
    {
        return $this->getData(self::OTHER_FEES) === null ? null
            : (float)$this->getData(self::OTHER_FEES);
    }

    /**
     * Setter for OtherFees.
     *
     * @param float|null $otherFees
     *
     * @return void
     */
    public function setOtherFees(?float $otherFees): void
    {
        $this->setData(self::OTHER_FEES, $otherFees);
    }
}
