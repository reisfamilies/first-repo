<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model;

/**
 * Class RegistryConstants
 * @package Tigren\MerchantManagement\Model
 */
class RegistryConstants
{
    /**#@+
     * Constants defined for dataPersistor
     */
    public const MERCHANT_DATA = 'merchant_management';
    /**#@-*/
}
