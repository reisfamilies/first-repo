<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model;

use Magento\Cron\Model\Schedule;
use Magento\Cron\Model\ScheduleFactory;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Tigren\MerchantManagement\Api\ScheduleManagementInterface;
use Tigren\MerchantManagement\Api\ScheduleRepositoryInterface;

/**
 * Class ScheduleManagement
 * @package Tigren\MerchantManagement\Model
 */
class ScheduleManagement implements ScheduleManagementInterface
{
    /**
     * @var ScheduleRepositoryInterface
     */
    private ScheduleRepositoryInterface $scheduleRepository;

    /**
     * @var DateTime
     */
    private DateTime $dateTime;

    /**
     * @var ScheduleFactory
     */
    private ScheduleFactory $scheduleFactory;

    /**
     * ScheduleManagement Constructor.
     *
     * @param ScheduleRepositoryInterface $scheduleRepository
     * @param DateTime $dateTime
     * @param ScheduleFactory $scheduleFactory
     */
    public function __construct(
        ScheduleRepositoryInterface $scheduleRepository,
        DateTime $dateTime,
        ScheduleFactory $scheduleFactory
    ) {
        $this->scheduleRepository = $scheduleRepository;
        $this->dateTime = $dateTime;
        $this->scheduleFactory = $scheduleFactory;
    }

    public function scheduleNow(string $jobCode): Schedule
    {
        $time = $this->dateTime->gmtTimestamp();
        $schedule = $this->scheduleFactory->create()
            ->setJobCode($jobCode)
            ->setStatus(Schedule::STATUS_PENDING)
            ->setCreatedAt(
                date(ScheduleManagementInterface::TIME_FORMAT, $this->dateTime->gmtTimestamp())
            )->setScheduledAt($time);

        $this->scheduleRepository->save($schedule);

        return $schedule;
    }
}
