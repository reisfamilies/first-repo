<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model;

use Exception;
use Magento\Cron\Model\ResourceModel\Schedule as ScheduleResource;
use Magento\Cron\Model\Schedule;
use Magento\Cron\Model\ScheduleFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Tigren\MerchantManagement\Api\ScheduleRepositoryInterface;

/**
 * Class ScheduleRepository
 * @package Tigren\MerchantManagement\Model
 */
class ScheduleRepository implements ScheduleRepositoryInterface
{
    /**
     * @var ScheduleResource
     */
    private ScheduleResource $scheduleResource;

    /**
     * @var array
     */
    private array $scheduleCache = [];

    /**
     * ScheduleRepository Constructor.
     *
     * @param ScheduleResource $scheduleResource
     */
    public function __construct(
        ScheduleResource $scheduleResource
    ) {
        $this->scheduleResource = $scheduleResource;
    }

    public function save(Schedule $schedule): Schedule
    {
        try {
            $this->scheduleResource->save($schedule);
        } catch (Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }
        unset($this->scheduleCache[$schedule->getId()]);

        return $schedule;
    }
}
