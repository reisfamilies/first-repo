<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model\Backend\Merchant;

use Tigren\MerchantManagement\Api\Data\MerchantInterface;

/**
 * Class Registry
 * @package Tigren\MerchantManagement\Model\Backend\Merchant
 */
class Registry
{
    /**
     * @var MerchantInterface|null
     */
    private ?MerchantInterface $merchant;

    public function set(MerchantInterface $merchant): void
    {
        $this->merchant = $merchant;
    }

    public function get(): MerchantInterface
    {
        return $this->merchant;
    }
}
