<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model\Repository;

use Exception;
use Magento\Framework\Api\Search\FilterGroup;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchResultsInterface;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Ui\Api\Data\BookmarkSearchResultsInterfaceFactory;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;
use Tigren\MerchantManagement\Api\MerchantRepositoryInterface;
use Tigren\MerchantManagement\Model\Merchant;
use Tigren\MerchantManagement\Model\MerchantFactory;
use Tigren\MerchantManagement\Model\ResourceModel\Merchant as MerchantResource;
use Tigren\MerchantManagement\Model\ResourceModel\Merchant\Collection;
use Tigren\MerchantManagement\Model\ResourceModel\Merchant\CollectionFactory;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class MerchantRepository implements MerchantRepositoryInterface
{
    /**
     * Model data storage
     *
     * @var array
     */
    private array $merchantModels;

    /**
     * @var BookmarkSearchResultsInterfaceFactory
     */
    private BookmarkSearchResultsInterfaceFactory $searchResultsFactory;

    /**
     * @var MerchantFactory
     */
    private MerchantFactory $merchantFactory;

    /**
     * @var MerchantResource
     */
    private MerchantResource $merchantResource;

    /**
     * @var CollectionFactory
     */
    private CollectionFactory $merchantCollectionFactory;

    /**
     * MerchantRepository Constructor.
     *
     * @param BookmarkSearchResultsInterfaceFactory $searchResultsFactory
     * @param MerchantFactory $merchantFactory
     * @param MerchantResource $merchantResource
     * @param CollectionFactory $merchantCollectionFactory
     */
    public function __construct(
        BookmarkSearchResultsInterfaceFactory $searchResultsFactory,
        MerchantFactory $merchantFactory,
        MerchantResource $merchantResource,
        CollectionFactory $merchantCollectionFactory
    ) {
        $this->searchResultsFactory = $searchResultsFactory;
        $this->merchantFactory = $merchantFactory;
        $this->merchantResource = $merchantResource;
        $this->merchantCollectionFactory = $merchantCollectionFactory;
    }

    /**
     * @inheritdoc
     */
    public function save(MerchantInterface $merchant)
    {
        try {
            if ($merchant->getMerchantId()) {
                $merchant = $this->getById($merchant->getMerchantId())->addData($merchant->getData());
            }

            $this->merchantResource->save($merchant);
            unset($this->merchantModels[$merchant->getMerchantId()]);
        } catch (Exception $e) {
            if ($merchant->getMerchantId()) {
                throw new CouldNotSaveException(
                    __(
                        'Unable to save merchant with ID %1. Error: %2',
                        [$merchant->getMerchantId(), $e->getMessage()]
                    )
                );
            }
            throw new CouldNotSaveException(__('Unable to save new merchant. Error: %1', $e->getMessage()));
        }

        return $merchant;
    }

    /**
     * @param int $merchantId
     * @return MerchantInterface
     * @throws NoSuchEntityException
     */
    public function getById($merchantId)
    {
        if (!isset($this->merchantModels[$merchantId])) {
            /** @var Merchant $merchant */
            $merchant = $this->merchantFactory->create();
            $this->merchantResource->load($merchant, $merchantId);
            if (!$merchant->getMerchantId()) {
                throw new NoSuchEntityException(__('Merchant with specified ID "%1" not found.', $merchantId));
            }

            $this->merchantModels[$merchantId] = $merchant;
        }

        return $this->merchantModels[$merchantId];
    }

    /**
     * @param string $merchantCode
     * @return MerchantInterface
     * @throws NoSuchEntityException
     */
    public function getByMerchantCode($merchantCode)
    {
        /** @var Merchant $merchant */
        $merchant = $this->merchantFactory->create();
        $this->merchantResource->load($merchant, $merchantCode, MerchantInterface::MERCHANT_CODE);
        if (!$merchant->getMerchantId()) {
            throw new NoSuchEntityException(__('Merchant with specified code "%1" not found.', $merchantCode));
        }

        $merchantId = $merchant->getMerchantId();
        $this->merchantModels[$merchantId] = $merchant;

        return $this->merchantModels[$merchantId];
    }

    /**
     * @param int $merchantId
     * @return bool
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($merchantId)
    {
        $merchantModel = $this->getById($merchantId);
        $this->delete($merchantModel);

        return true;
    }

    /**
     * @param MerchantInterface $merchant
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(MerchantInterface $merchant)
    {
        try {
            $this->merchantResource->delete($merchant);
            unset($this->merchantModels[$merchant->getMerchantId()]);
        } catch (Exception $e) {
            if ($merchant->getMerchantId()) {
                throw new CouldNotDeleteException(
                    __(
                        'Unable to remove merchant with ID %1. Error: %2',
                        [$merchant->getMerchantId(), $e->getMessage()]
                    )
                );
            }
            throw new CouldNotDeleteException(__('Unable to remove merchant. Error: %1', $e->getMessage()));
        }

        return true;
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return SearchResultsInterface
     * @throws NoSuchEntityException
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        /** @var Collection $merchantCollection */
        $merchantCollection = $this->merchantCollectionFactory->create();

        // Add filters from root filter group to the collection
        foreach ($searchCriteria->getFilterGroups() as $group) {
            $this->addFilterGroupToCollection($group, $merchantCollection);
        }

        $searchResults->setTotalCount($merchantCollection->getSize());
        $sortOrders = $searchCriteria->getSortOrders();

        if ($sortOrders) {
            $this->addOrderToCollection($sortOrders, $merchantCollection);
        }

        $merchantCollection->setCurPage($searchCriteria->getCurrentPage());
        $merchantCollection->setPageSize($searchCriteria->getPageSize());

        $merchantModels = [];
        /** @var MerchantInterface $merchant */
        foreach ($merchantCollection->getItems() as $merchant) {
            $merchantModels[] = $this->getById($merchant->getMerchantId());
        }

        $searchResults->setItems($merchantModels);

        return $searchResults;
    }

    /**
     * Helper function that adds a FilterGroup to the collection.
     *
     * @param FilterGroup $filterGroup
     * @param Collection $merchantCollection
     *
     * @return void
     */
    private function addFilterGroupToCollection(FilterGroup $filterGroup, Collection $merchantCollection)
    {
        foreach ($filterGroup->getFilters() as $filter) {
            $condition = $filter->getConditionType() ?: 'eq';
            $merchantCollection->addFieldToFilter($filter->getField(), [$condition => $filter->getValue()]);
        }
    }

    /**
     * Helper function that adds a SortOrder to the collection.
     *
     * @param SortOrder[] $sortOrders
     * @param Collection $merchantCollection
     *
     * @return void
     */
    private function addOrderToCollection($sortOrders, Collection $merchantCollection)
    {
        /** @var SortOrder $sortOrder */
        foreach ($sortOrders as $sortOrder) {
            $field = $sortOrder->getField();
            $merchantCollection->addOrder(
                $field,
                ($sortOrder->getDirection() == SortOrder::SORT_DESC) ? SortOrder::SORT_DESC : SortOrder::SORT_ASC
            );
        }
    }

    /**
     * @return MerchantInterface
     */
    public function getEmptyModel()
    {
        return $this->merchantFactory->create();
    }
}
