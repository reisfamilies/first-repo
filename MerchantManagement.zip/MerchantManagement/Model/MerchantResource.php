<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model;

use Exception;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;
use Tigren\MerchantManagement\Api\MerchantRepositoryInterface;
use Tigren\MuneroIntegration\Helper\Base as MuneroHelper;
use Tigren\MuneroIntegration\Helper\Logging;

/**
 * Class MerchantResource
 * @package Tigren\MerchantManagement\Model
 */
class MerchantResource
{
    /**
     * @var MerchantRepositoryInterface
     */
    private MerchantRepositoryInterface $merchantRepository;

    /**
     * @var MuneroHelper
     */
    private MuneroHelper $muneroHelper;

    /**
     * @var Logging
     */
    private Logging $logging;

    /**
     * MerchantResource Constructor.
     *
     * @param MerchantRepositoryInterface $merchantRepository
     * @param MuneroHelper $muneroHelper
     * @param Logging $logging
     */
    public function __construct(
        MerchantRepositoryInterface $merchantRepository,
        MuneroHelper $muneroHelper,
        Logging $logging
    ) {
        $this->merchantRepository = $merchantRepository;
        $this->muneroHelper = $muneroHelper;
        $this->logging = $logging;
    }

    public function syncMerchants(array $queryParams = []): bool
    {
        $this->logging->writeLog('[START SYNC MERCHANTS]');
        $issueCount = 0;
        try {
            $endPoint = 'uos/merchants/query';
            $response = $this->muneroHelper->callMuneroAPI($this->buildApiUrl($endPoint, $queryParams), 'GET', 0);
            if (empty($response['results']) || !is_array($response['results'])) {
                $this->logging->writeLog('[NO MERCHANTS TO SYNC]');
                return true;
            }

            foreach ($response['results'] as $result) {
                if (!$this->processMerchant($result)) {
                    $issueCount++;
                }
            }
        } catch (Exception $e) {
            $this->logging->writeLog('[ERROR SYNC MERCHANTS]', [$e->getMessage()]);
            return false;
        }

        $this->logging->writeLog('[END SYNC MERCHANTS]');

        return $issueCount === 0;
    }

    private function processMerchant(array $result): bool
    {
        try {
            $merchantData = $this->extractMerchantData($result);
            $merchant = $this->findOrCreateMerchant($merchantData['merchant_code']);
            if (!empty($merchant->getMerchantId())) {
                $merchantData += ['merchant_id' => $merchant->getMerchantId()];
            }

            $merchant->setData($merchantData);
            $this->merchantRepository->save($merchant);
            $this->logging->writeLog('[SYNC MERCHANT SUCCESS]', [$merchant->getMerchantCode()]);
            return true;
        } catch (Exception $e) {
            $this->logging->writeLog('[ERROR SYNC MERCHANT]', [$e->getMessage()]);
            return false;
        }
    }

    private function extractMerchantData(array $result): array
    {
        $merchantData = [
            'merchant_code' => $result['id'] ?? '',
            'merchant_name' => isset($result['name']) ? reset($result['name']) : '',
            'website' => $result['website'] ?? '',
            'logo' => $result['logoUrl'] ?? '',
            'logo_thumbnail' => $result['logoThumbnailUrl'] ?? '',
            'address' => $result['address'] ?? '',
            'brief_description' => isset($result['briefDescription']) ? reset($result['briefDescription']) : '',
        ];

        if (!empty($result['contactInfo'])) {
            $merchantData += $this->extractContactInfo($result['contactInfo']);
        }

        return $merchantData;
    }

    private function extractContactInfo(array $contactInfo): array
    {
        return [
            'contact_person_name' => isset($contactInfo['contactPersonName']) ? reset($contactInfo['contactPersonName']) : '',
            'email_address' => $contactInfo['emailAddress'] ?? '',
            'phone_number' => $contactInfo['phoneNo'] ?? '',
            'mobile_number' => $contactInfo['mobileNo'] ?? '',
        ];
    }

    /**
     * @throws LocalizedException
     */
    private function findOrCreateMerchant(string $merchantCode): MerchantInterface
    {
        try {
            return $this->merchantRepository->getByMerchantCode($merchantCode);
        } catch (NoSuchEntityException) {
            return $this->merchantRepository->getEmptyModel();
        }
    }

    private function buildApiUrl(string $endpoint, array $queryParams): string
    {
        return empty($queryParams) ? $endpoint : $endpoint . '?' . http_build_query($queryParams);
    }

}
