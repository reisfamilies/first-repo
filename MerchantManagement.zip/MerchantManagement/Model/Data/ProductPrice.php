<?php

namespace Tigren\MerchantManagement\Model\Data;

use Magento\Framework\DataObject;
use Tigren\MerchantManagement\Api\Data\ProductPriceInterface;

class ProductPrice extends DataObject implements ProductPriceInterface
{

}
