<?php

namespace Tigren\MerchantManagement\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Tigren\MerchantManagement\Api\Data\ProductPriceInterface;

class ProductPrice extends AbstractDb
{
    public const CATALOG_PRODUCT_ENTITY_TABLE = 'catalog_product_entity';

//    public function getProductIdsByProjectId($projectId)
//    {
//        $select = $this->getConnection()
//            ->select()
//            ->from(['main_table' => $this->getMainTable()], ['product_id'])
//            ->where('main_table.project_id = ?', $projectId);
//
//        return $this->getConnection()->fetchCol($select);
//    }

//    public function getProjectIdsByProductId($productIds)
//    {
//        $select = $this->getConnection()
//            ->select()
//            ->from(['main_table' => $this->getMainTable()], ['project_id'])
//            ->where('main_table.product_id in (?)', $productIds);
//
//        return $this->getConnection()->fetchCol($select);
//    }

//    public function unassignProject($productIds = [])
//    {
//        if (!empty($productIds)) {
//            $this->getConnection()->update(
//                $this->getTable(ProductPriceInterface::TABLE_NAME),
//                [ProductInterface::PROJECT_ID => null],
//                ['product_id in (?)' => $productIds]
//            );
//        }
//
//        return $this;
//    }

//    public function assignToMerchant($merchantId, $productPrices = [])
//    {
//        $insertData = [];
//        foreach ($productPrices as $productPrice) {
//            $data = [
//                ProductPriceInterface::PRODUCT_ID => $productId,
//                ProductPriceInterface::PROJECT_ID => $projectId,
//            ];
//            $insertData[] = $data;
//        }
//
//        $this->getConnection()->insertOnDuplicate($this->getMainTable(), $insertData);
//
//        return $this;
//    }

    public function removeMerchantProductPrice($merchantId)
    {
        if (!empty($projectId)) {
            $this->getConnection()->delete($this->getMainTable(), ['merchant_id = ?' => $merchantId]);
        }

        return $this;
    }

    protected function _construct()
    {
        $this->_init(ProductPriceInterface::TABLE_NAME, ProductPriceInterface::ENTITY_ID);
    }
}
