<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model\ResourceModel\Merchant\Grid;

use Tigren\MerchantManagement\Api\Data\MerchantInterface;
use Tigren\MerchantManagement\Model\Merchant;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface as FetchStrategy;
use Magento\Framework\Data\Collection\EntityFactoryInterface as EntityFactory;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;
use Psr\Log\LoggerInterface as Logger;

/**
 * Class Collection
 * @package Tigren\MerchantManagement\Model\ResourceModel\Merchant\Grid
 */
class Collection extends SearchResult
{
    /**
     * @var string
     */
    protected $document = Merchant::class;

    public function __construct(
        EntityFactory $entityFactory,
        Logger $logger,
        FetchStrategy $fetchStrategy,
        EventManager $eventManager,
        $mainTable = MerchantInterface::TABLE_NAME,
        $resourceModel = \Tigren\MerchantManagement\Model\ResourceModel\Merchant::class
    ) {
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $mainTable, $resourceModel);
    }
}
