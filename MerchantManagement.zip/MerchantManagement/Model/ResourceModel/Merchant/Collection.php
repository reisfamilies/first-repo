<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model\ResourceModel\Merchant;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Tigren\MerchantManagement\Model\Merchant as Model;
use Tigren\MerchantManagement\Model\ResourceModel\Merchant as ResourceModel;

/**
 * Class Collection
 * @package Tigren\MerchantManagement\Model\ResourceModel\Merchant
 */
class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_eventPrefix = 'tigren_merchant_collection';

    /**
     * Initialize collection model.
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
