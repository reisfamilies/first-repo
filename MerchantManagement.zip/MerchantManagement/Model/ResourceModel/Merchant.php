<?php
/*
 * @author    Tigren Solutions <info@tigren.com>
 * @copyright Copyright (c) 2025 Tigren Solutions <https://www.tigren.com>. All rights reserved.
 * @license   Open Software License ("OSL") v. 3.0
 */

namespace Tigren\MerchantManagement\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Tigren\MerchantManagement\Api\Data\MerchantInterface;

/**
 * Class Merchant
 * @package Tigren\MerchantManagement\Model\ResourceModel
 */
class Merchant extends AbstractDb
{
    /**
     * @var string
     */
    protected $_eventPrefix = 'tigren_merchant_resource_model';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('tigren_merchant', MerchantInterface::MERCHANT_ID);
        $this->_useIsObjectNew = true;
    }
}
