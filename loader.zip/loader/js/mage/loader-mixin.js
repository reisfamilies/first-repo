define([
    'jquery',
    'mage/template'
], function (
    $, mageTemplate
) {
    'use strict';

    var loaderMixin = {
        _bind: function () {
            this._on({
                'processStop': 'hide',
                'processStart': 'show',
                'processStartAfterPayment': 'showAfterPayment',
                'show.loader': 'show',
                'hide.loader': 'hide',
                'contentUpdated.loader': '_contentUpdated'
            });
        },
        showAfterPayment: function (e, ctx) {
            this.options.texts.loaderText = $.mage.__('Please wait while we process your payment...');
            this.options.template = '<div class="loading-mask" data-role="loader">' +
                '<div class="loader">' +
                '<img alt="<%- data.texts.imgAlt %>" src="<%- data.icon %>">' +
                '<p><%- data.texts.loaderText %></p>' +
                '</div>' +
                '</div>' +  '<p><%- data.texts.loaderText %></p>';

            this._renderCheckout();
            this.loaderStarted++;
            this.spinner.show();

            if (ctx) {
                this.spinner
                    .css({
                        width: ctx.outerWidth(),
                        height: ctx.outerHeight(),
                        position: 'absolute'
                    })
                    .position({
                        my: 'top left',
                        at: 'top left',
                        of: ctx
                    });
            }

            return false;
        },

        _renderCheckout: function () {
            var html;

            if (!this.spinnerTemplateCheckout) {
                this.spinnerTemplateCheckout = mageTemplate(this.options.template);

                html = $(this.spinnerTemplateCheckout({
                    data: this.options
                }));

                html.prependTo(this.element);

                this.spinner = html;
            }
        },

    };

    return function (targetWidget) {
        $.widget('mage.loader', targetWidget.loader, loaderMixin);
        return $.mage.loader;
    };
});
