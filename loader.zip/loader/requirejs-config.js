var config = {
    "config": {
        "mixins": {
            "mage/loader": {
                "js/mage/loader-mixin": true
            }
        }
    }
};
